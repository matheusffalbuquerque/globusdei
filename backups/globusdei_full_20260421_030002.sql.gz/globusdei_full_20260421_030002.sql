--
-- PostgreSQL database dump
--

\restrict ZcPJdcn2h74ebgUTjJytTlNbKSiRCKway7Tfgn6mVd4sisk2c6p5aaiG1lCng2Q

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA app;


--
-- Name: AgentInvestmentTargetType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."AgentInvestmentTargetType" AS ENUM (
    'AGENT',
    'EMPREENDIMENTO'
);


--
-- Name: AgentInvestmentType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."AgentInvestmentType" AS ENUM (
    'ONE_TIME',
    'RECURRING'
);


--
-- Name: AgentStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."AgentStatus" AS ENUM (
    'ENTERED',
    'SUBMITTED',
    'QUALIFIED',
    'SCHEDULED',
    'APPROVED',
    'REJECTED'
);


--
-- Name: AnnouncementType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."AnnouncementType" AS ENUM (
    'SYSTEM',
    'MISSION',
    'EVENT'
);


--
-- Name: CollaboratorRole; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."CollaboratorRole" AS ENUM (
    'ADMIN',
    'PEOPLE_MANAGER',
    'PROJECT_MANAGER',
    'RESOURCE_MANAGER'
);


--
-- Name: ConnectionStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."ConnectionStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED'
);


--
-- Name: EmpreendimentoAgentRole; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."EmpreendimentoAgentRole" AS ENUM (
    'OWNER',
    'MANAGER',
    'CONTRIBUTOR',
    'VOLUNTEER'
);


--
-- Name: EmpreendimentoCategory; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."EmpreendimentoCategory" AS ENUM (
    'EDUCATION',
    'SPORTS',
    'TECHNOLOGY',
    'BUSINESS',
    'HEALTH',
    'SOCIAL',
    'SCIENTIFICAL',
    'CAPACITATION',
    'SUPPORT'
);


--
-- Name: EmpreendimentoType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."EmpreendimentoType" AS ENUM (
    'CHURCH',
    'AGENCY',
    'SCHOOL',
    'PROJECT',
    'VENTURE',
    'ONG'
);


--
-- Name: FinalWorkStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."FinalWorkStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: FinancialEntryType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."FinancialEntryType" AS ENUM (
    'INCOME',
    'EXPENSE',
    'ADJUSTMENT',
    'TRANSFER'
);


--
-- Name: FinancialTargetType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."FinancialTargetType" AS ENUM (
    'ORGANIZATION',
    'AGENT',
    'EMPREENDIMENTO'
);


--
-- Name: FollowUpStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."FollowUpStatus" AS ENUM (
    'OPEN',
    'MONITORING',
    'ON_HOLD',
    'CLOSED'
);


--
-- Name: InviteStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."InviteStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED'
);


--
-- Name: LanguageProficiency; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."LanguageProficiency" AS ENUM (
    'BASIC',
    'INTERMEDIATE',
    'ADVANCED',
    'FLUENT',
    'NATIVE'
);


--
-- Name: NeedType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."NeedType" AS ENUM (
    'MAINTENANCE',
    'EXPANSION',
    'EMERGENCY'
);


--
-- Name: NotificationEmailStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."NotificationEmailStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED'
);


--
-- Name: NotificationScope; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."NotificationScope" AS ENUM (
    'PERSONAL',
    'INITIATIVE',
    'PLATFORM'
);


--
-- Name: NotificationTargetType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."NotificationTargetType" AS ENUM (
    'AGENT',
    'COLLABORATOR',
    'EMPREENDIMENTO'
);


--
-- Name: NotificationType; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."NotificationType" AS ENUM (
    'DIRECT_MESSAGE',
    'CONNECTION_REQUEST',
    'NEW_FOLLOWER',
    'EVENT_REMINDER',
    'PROCESS_UPDATE',
    'SYSTEM_ANNOUNCEMENT'
);


--
-- Name: OpportunityCategory; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."OpportunityCategory" AS ENUM (
    'STUDIES',
    'VOLUNTEERING',
    'EMPLOYMENT',
    'MISSION',
    'ROLE',
    'TRAVEL',
    'OTHER'
);


--
-- Name: PrayerRequestStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."PrayerRequestStatus" AS ENUM (
    'PENDING',
    'ANSWERED'
);


--
-- Name: ServiceRequestCategory; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."ServiceRequestCategory" AS ENUM (
    'TECHNICAL',
    'PSYCHOLOGICAL',
    'MEDICAL',
    'SPIRITUAL',
    'MENTORSHIP',
    'LEGAL'
);


--
-- Name: ServiceRequestStatus; Type: TYPE; Schema: app; Owner: -
--

CREATE TYPE app."ServiceRequestStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'RESOLVED',
    'CLOSED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AcademyModule; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AcademyModule" (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "coverUrl" text,
    "isPublished" boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "workInstructions" text DEFAULT ''::text NOT NULL
);


--
-- Name: Agent; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Agent" (
    id text NOT NULL,
    "authSubject" text,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    "publicBio" text,
    "privateNotes" text,
    city text,
    country text,
    "isActive" boolean DEFAULT true NOT NULL,
    status app."AgentStatus" DEFAULT 'ENTERED'::app."AgentStatus" NOT NULL,
    "scheduledSlotId" text,
    "interviewLink" text,
    "interviewDate" timestamp(3) without time zone,
    "interviewerId" text,
    feedback text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "birthDate" timestamp(3) without time zone,
    "coverUrl" text,
    "currentDenomination" text,
    "nationalityId" text,
    "photoUrl" text,
    "portfolioUrl" text,
    "shortDescription" text,
    slug text,
    state text
);


--
-- Name: AgentCertification; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentCertification" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "moduleId" text NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AgentCourse; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentCourse" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    title text NOT NULL,
    institution text NOT NULL,
    "issueDate" timestamp(3) without time zone,
    "certificateUrl" text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentEducation; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentEducation" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    institution text NOT NULL,
    course text NOT NULL,
    degree text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentExperience; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentExperience" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "experienceTypeId" text NOT NULL,
    title text NOT NULL,
    organization text NOT NULL,
    location text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentInvestment; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentInvestment" (
    id text NOT NULL,
    "investorId" text NOT NULL,
    "targetType" app."AgentInvestmentTargetType" NOT NULL,
    "targetAgentId" text,
    "targetEmpreendimentoId" text,
    amount double precision NOT NULL,
    type app."AgentInvestmentType" DEFAULT 'ONE_TIME'::app."AgentInvestmentType" NOT NULL,
    notes text,
    "investedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentLanguage; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentLanguage" (
    "agentId" text NOT NULL,
    "languageId" text NOT NULL,
    "proficiencyLevel" app."LanguageProficiency" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AgentLink; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentLink" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    title text NOT NULL,
    url text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentModuleEnrollment; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentModuleEnrollment" (
    "agentId" text NOT NULL,
    "moduleId" text NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AgentRecommendation; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentRecommendation" (
    id text NOT NULL,
    "recommenderId" text NOT NULL,
    "recommendedId" text NOT NULL,
    text text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgentSkill; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentSkill" (
    "agentId" text NOT NULL,
    "skillId" text NOT NULL,
    "contextInfo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AgentVocationalArea; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AgentVocationalArea" (
    "agentId" text NOT NULL,
    "vocationalAreaId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Allocation; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Allocation" (
    id text NOT NULL,
    amount double precision NOT NULL,
    description text,
    "targetType" app."FinancialTargetType" NOT NULL,
    "targetId" text NOT NULL,
    "targetName" text NOT NULL,
    "recordedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Announcement; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Announcement" (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type app."AnnouncementType" DEFAULT 'SYSTEM'::app."AnnouncementType" NOT NULL,
    "targetId" text,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Answer; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Answer" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "questionId" text NOT NULL,
    text text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AuditLog" (
    id text NOT NULL,
    "actorId" text NOT NULL,
    "actionType" text NOT NULL,
    "actionDetail" text NOT NULL,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "actorEmail" text,
    "actorName" text,
    entity text
);


--
-- Name: AvailabilitySlot; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."AvailabilitySlot" (
    id text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    "collaboratorId" text NOT NULL,
    "meetLink" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Collaborator; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Collaborator" (
    id text NOT NULL,
    "authSubject" text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    roles app."CollaboratorRole"[],
    "expertiseAreas" text[],
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Connection; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Connection" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    status app."ConnectionStatus" DEFAULT 'PENDING'::app."ConnectionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Empreendimento; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Empreendimento" (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    "establishedDate" timestamp(3) without time zone NOT NULL,
    type app."EmpreendimentoType" NOT NULL,
    category app."EmpreendimentoCategory" NOT NULL,
    "socialLinks" jsonb,
    "portfolioUrl" text,
    location text,
    "actuationRegions" text,
    "logoUrl" text,
    "bannerUrl" text,
    "monthlyExpenses" double precision DEFAULT 0 NOT NULL,
    "incomeSources" text,
    "needType" app."NeedType" DEFAULT 'MAINTENANCE'::app."NeedType" NOT NULL,
    "receivesInvestments" boolean DEFAULT false NOT NULL,
    "isBankVerified" boolean DEFAULT false NOT NULL,
    "bankDetails" text,
    "priorityScore" integer DEFAULT 0 NOT NULL,
    "followUpStatus" app."FollowUpStatus" DEFAULT 'OPEN'::app."FollowUpStatus" NOT NULL,
    "internalNotes" text,
    "internalResponsibleId" text,
    "ownerId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EmpreendimentoFollow; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."EmpreendimentoFollow" (
    "agentId" text NOT NULL,
    "empreendimentoId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: EmpreendimentoInvite; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."EmpreendimentoInvite" (
    id text NOT NULL,
    "empreendimentoId" text NOT NULL,
    email text NOT NULL,
    role app."EmpreendimentoAgentRole" DEFAULT 'CONTRIBUTOR'::app."EmpreendimentoAgentRole" NOT NULL,
    status app."InviteStatus" DEFAULT 'PENDING'::app."InviteStatus" NOT NULL,
    token text NOT NULL,
    "inviterId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EmpreendimentoMember; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."EmpreendimentoMember" (
    "agentId" text NOT NULL,
    "empreendimentoId" text NOT NULL,
    role app."EmpreendimentoAgentRole" DEFAULT 'CONTRIBUTOR'::app."EmpreendimentoAgentRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Event; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Event" (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    location text,
    "isOnline" boolean DEFAULT false NOT NULL,
    "isCancelled" boolean DEFAULT false NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EventRsvp; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."EventRsvp" (
    id text NOT NULL,
    "eventId" text NOT NULL,
    "agentId" text NOT NULL,
    confirmed boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ExpenseCategory; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."ExpenseCategory" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "entryType" app."FinancialEntryType" DEFAULT 'EXPENSE'::app."FinancialEntryType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ExperienceType; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."ExperienceType" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: FinalWork; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."FinalWork" (
    id text NOT NULL,
    "moduleId" text NOT NULL,
    "agentId" text NOT NULL,
    content text,
    "fileUrl" text,
    status app."FinalWorkStatus" DEFAULT 'PENDING'::app."FinalWorkStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: FinalWorkReview; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."FinalWorkReview" (
    id text NOT NULL,
    "workId" text NOT NULL,
    "collaboratorId" text NOT NULL,
    feedback text NOT NULL,
    approved boolean NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: FinancialEntry; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."FinancialEntry" (
    id text NOT NULL,
    type app."FinancialEntryType" NOT NULL,
    amount double precision NOT NULL,
    description text NOT NULL,
    "occurredAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "targetType" app."FinancialTargetType",
    "targetId" text,
    "targetName" text,
    "categoryId" text,
    "recordedById" text NOT NULL,
    "investmentId" text,
    "allocationId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Investment; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Investment" (
    id text NOT NULL,
    amount double precision NOT NULL,
    description text,
    "targetType" app."FinancialTargetType" NOT NULL,
    "targetId" text,
    "targetName" text,
    "recordedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Language; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Language" (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Lesson; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Lesson" (
    id text NOT NULL,
    "moduleId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "youtubeUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: LessonAnswer; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."LessonAnswer" (
    id text NOT NULL,
    "questionId" text NOT NULL,
    "collaboratorId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: LessonMaterial; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."LessonMaterial" (
    id text NOT NULL,
    "lessonId" text NOT NULL,
    title text NOT NULL,
    url text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: LessonProgress; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."LessonProgress" (
    id text NOT NULL,
    "lessonId" text NOT NULL,
    "agentId" text NOT NULL,
    "completedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: LessonQuestion; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."LessonQuestion" (
    id text NOT NULL,
    "lessonId" text NOT NULL,
    "agentId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Nationality; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Nationality" (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Notification" (
    id text NOT NULL,
    type app."NotificationType" NOT NULL,
    scope app."NotificationScope" DEFAULT 'PERSONAL'::app."NotificationScope" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "actionUrl" text,
    metadata jsonb,
    "sourceEntityType" text,
    "sourceEntityId" text,
    "senderAgentId" text,
    "senderCollaboratorId" text,
    "senderSystemLabel" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: NotificationEmailLog; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."NotificationEmailLog" (
    id text NOT NULL,
    "notificationId" text,
    "senderCollaboratorId" text NOT NULL,
    "targetType" app."NotificationTargetType" NOT NULL,
    "agentId" text,
    "empreendimentoId" text,
    "recipientName" text,
    "recipientEmail" text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    status app."NotificationEmailStatus" DEFAULT 'PENDING'::app."NotificationEmailStatus" NOT NULL,
    provider text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: NotificationRecipient; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."NotificationRecipient" (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "targetType" app."NotificationTargetType" NOT NULL,
    "agentId" text,
    "collaboratorId" text,
    "empreendimentoId" text,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Opportunity; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Opportunity" (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    category app."OpportunityCategory" DEFAULT 'OTHER'::app."OpportunityCategory" NOT NULL,
    location text,
    "isRemote" boolean DEFAULT false NOT NULL,
    "isPublished" boolean DEFAULT true NOT NULL,
    "authorCollaboratorId" text,
    "authorAgentId" text,
    "empreendimentoId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PrayerRequest; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."PrayerRequest" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    request text NOT NULL,
    status app."PrayerRequestStatus" DEFAULT 'PENDING'::app."PrayerRequestStatus" NOT NULL,
    "answeredById" text,
    "answeredAt" timestamp(3) without time zone,
    "internalNote" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Question; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Question" (
    id text NOT NULL,
    title text NOT NULL,
    "isRequired" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ServiceLog; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."ServiceLog" (
    id text NOT NULL,
    "empreendimentoId" text NOT NULL,
    "collaboratorId" text NOT NULL,
    action text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ServiceRequest; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."ServiceRequest" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    category app."ServiceRequestCategory" NOT NULL,
    status app."ServiceRequestStatus" DEFAULT 'OPEN'::app."ServiceRequestStatus" NOT NULL,
    description text NOT NULL,
    "assignedCollaboratorId" text,
    "internalNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Skill; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."Skill" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: VocationalArea; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app."VocationalArea" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: app; Owner: -
--

CREATE TABLE app._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AcademyModule; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AcademyModule" (id, title, description, "coverUrl", "isPublished", "order", "createdAt", "updatedAt", "workInstructions") FROM stdin;
27f02c53-5add-4538-a478-d36a270c4be4	Kingdom Business	Primeiros passos	https://storage.googleapis.com/gpt-engineer-file-uploads/eQK5Y78WiMUaPymU0kqVUZhhpv52/social-images/social-1764690333925-Logo%20(6).png	t	1	2026-04-15 16:11:52.282	2026-04-15 16:16:49.33	Teste final
\.


--
-- Data for Name: Agent; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Agent" (id, "authSubject", name, email, phone, "publicBio", "privateNotes", city, country, "isActive", status, "scheduledSlotId", "interviewLink", "interviewDate", "interviewerId", feedback, "createdAt", "updatedAt", "birthDate", "coverUrl", "currentDenomination", "nationalityId", "photoUrl", "portfolioUrl", "shortDescription", slug, state) FROM stdin;
c807bee5-8673-43a2-a00c-be056c5e0836	ea224a94-8055-4731-b900-659f73e1ea54	Leticia Siqueira de Paula Albuquerque	youcanpublicidade@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-15 16:07:00.968	2026-04-15 18:21:01.573	\N	\N	\N	\N	\N	\N	\N	\N	\N
78175a82-44aa-4a8a-afca-0914b8d68c6f	internal-service	Internal Service	internal@globusdei.local	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-21 00:30:50.41	2026-04-21 00:32:42.826	\N	\N	\N	\N	\N	\N	\N	\N	\N
0ff72fb8-4043-44d9-b488-62ead5123434	b07aabf6-7906-470f-96c1-827c2963e726	Rayssa Thiely Benavides	thielybenavidesrayssa@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-18 22:39:42.362	2026-04-18 22:39:42.362	\N	\N	\N	\N	\N	\N	\N	\N	\N
f5a295ab-14d2-4d37-9d4d-d08a4f9396ac	b440813c-30cb-4039-9bda-900ea3fe235a	Yerko Benavides Álvarez	yerkobenavidesalvarez@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-18 22:42:03.56	2026-04-18 22:42:03.56	\N	\N	\N	\N	\N	\N	\N	\N	\N
01398710-93a0-49e3-851d-f672dc90a0eb	e0e53383-45eb-46b1-bea1-9b11aa687b6f	Alle Silva	alexandreh2o@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-18 22:42:03.56	2026-04-18 22:42:03.56	\N	\N	\N	\N	\N	\N	\N	\N	\N
bdaa913b-7418-4fd9-af83-e7538d3cbf7f	cdd358d4-9443-4fab-80b1-93f5036104b3	Murila Oliveira Liberato	murilaliberato@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-17 13:13:24.252	2026-04-17 13:16:31.464	\N	\N	\N	\N	\N	\N	\N	\N	\N
cb24c29d-ba9f-493e-9ab5-84b3b9f61c67	afe2798d-82ca-492b-863e-257ae3162319	Sarah Katherine Benavides Alvarez	abcsarahkbenavides@gmail.com	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-17 10:35:27.397	2026-04-18 01:17:55.513	\N	\N	\N	\N	\N	\N	\N	\N	\N
908af585-b754-49a6-81d8-ef7b4fd93450	a37d959d-0f0a-4c99-b362-2dab0e468cd8	Letícia Albuquerque	leticiasiq027@gmail.com	18 99703-9730	Tenho uma família maravilhosa e sou fundadora, junto ao meu esposo da organização de apoio missionário Globus Dei.	\N	Ilha Solteira	Brasil	t	APPROVED	494ac3ea-510e-4db2-8c99-87bbf3613769	\N	2026-04-20 08:00:00	f4c7f164-34ef-4255-b5be-3083f1d70897	Parabéns, seja bem vinda!	2026-04-18 12:44:29.704	2026-04-21 02:59:50.846	\N		Agape House	\N			Mãe | Esposa | Filha do Rei	leticiasiqueira	SP
1755740e-d299-4da8-bba6-5c4ad52f0cc6	dc675cd2-e710-4158-9116-a4d5123e5f70	ISADORA DA SILVA DOS SANTOS	s.isadora@ufms.br	\N	\N	\N	\N	\N	t	ENTERED	\N	\N	\N	\N	\N	2026-04-18 22:42:03.56	2026-04-21 02:57:43.94	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: AgentCertification; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentCertification" (id, "agentId", "moduleId", "issuedAt") FROM stdin;
\.


--
-- Data for Name: AgentCourse; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentCourse" (id, "agentId", title, institution, "issueDate", "certificateUrl", description, "createdAt", "updatedAt") FROM stdin;
672fdc31-92c1-44da-9331-24cf13c4ef1a	908af585-b754-49a6-81d8-ef7b4fd93450	Inglês - Nível Básico	CNA	2023-11-20 00:00:00			2026-04-21 00:19:15.677	2026-04-21 00:19:15.677
\.


--
-- Data for Name: AgentEducation; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentEducation" (id, "agentId", institution, course, degree, "startDate", "endDate", description, "createdAt", "updatedAt") FROM stdin;
e2cbdebd-075f-4752-8716-6c6d320413e8	908af585-b754-49a6-81d8-ef7b4fd93450	Unicesumar	Marketing(Cursando)	Tecnólogo	2023-05-20 00:00:00	\N		2026-04-21 00:17:57.826	2026-04-21 00:17:57.826
2575498b-22b7-459a-ba44-1bdcdf78fcb4	1755740e-d299-4da8-bba6-5c4ad52f0cc6	Universidade Federal de Mato Grosso do Sul (UFMS)	Engenharia Ambiental	Bacharelado	2023-02-01 00:00:00	2027-12-10 00:00:00		2026-04-21 02:49:50.245	2026-04-21 02:49:50.245
25153371-fb66-47df-b486-cd8c989a7226	1755740e-d299-4da8-bba6-5c4ad52f0cc6	Instituto Federal de Mato Grosso do Sul (IFMS)	Técnico em Eletrotécnica	Ensino médio técnico integrado	2020-02-06 00:00:00	2022-12-12 00:00:00		2026-04-21 02:53:14.135	2026-04-21 02:53:14.135
\.


--
-- Data for Name: AgentExperience; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentExperience" (id, "agentId", "experienceTypeId", title, organization, location, "startDate", "endDate", description, "createdAt", "updatedAt") FROM stdin;
1c824441-7aac-4455-bbc3-4f4aab0c23ac	908af585-b754-49a6-81d8-ef7b4fd93450	0c8be6ba-0562-42ab-ab4a-16f4075aa69e	Trabalhei em loja de móveis de luxo	Casa Minas		2023-04-20 00:00:00	2023-05-21 00:00:00	Foi um bom tempo	2026-04-21 00:15:11.144	2026-04-21 00:15:11.144
40b32396-8071-43e3-9147-4f3f8947681e	908af585-b754-49a6-81d8-ef7b4fd93450	feb52bb5-1007-45c9-8848-4fc23edc2e5f	Fundação de uma ONG Missionária	Globus Dei		2024-04-06 00:00:00	2024-04-06 00:00:00	Iniciei uma ONG de apoio missionário durante o tempo que trabalhei em São Paulo	2026-04-21 00:16:55.204	2026-04-21 00:16:55.204
\.


--
-- Data for Name: AgentInvestment; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentInvestment" (id, "investorId", "targetType", "targetAgentId", "targetEmpreendimentoId", amount, type, notes, "investedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AgentLanguage; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentLanguage" ("agentId", "languageId", "proficiencyLevel", "createdAt") FROM stdin;
908af585-b754-49a6-81d8-ef7b4fd93450	4967a5d7-f599-4e7c-9b57-f3a65de949ab	BASIC	2026-04-21 02:37:40.881
908af585-b754-49a6-81d8-ef7b4fd93450	0f0c559d-3c97-488f-a2c8-eb75504b12cd	BASIC	2026-04-21 02:37:40.881
908af585-b754-49a6-81d8-ef7b4fd93450	b2150ccb-9a7c-4931-a1be-7673f0486a4f	NATIVE	2026-04-21 02:37:40.881
\.


--
-- Data for Name: AgentLink; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentLink" (id, "agentId", title, url, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AgentModuleEnrollment; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentModuleEnrollment" ("agentId", "moduleId", "enrolledAt") FROM stdin;
\.


--
-- Data for Name: AgentRecommendation; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentRecommendation" (id, "recommenderId", "recommendedId", text, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AgentSkill; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentSkill" ("agentId", "skillId", "contextInfo", "createdAt") FROM stdin;
908af585-b754-49a6-81d8-ef7b4fd93450	00b6036b-9b48-4b0a-91e3-4ff7d328f633	\N	2026-04-21 02:37:40.879
\.


--
-- Data for Name: AgentVocationalArea; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AgentVocationalArea" ("agentId", "vocationalAreaId", "createdAt") FROM stdin;
908af585-b754-49a6-81d8-ef7b4fd93450	c40976c3-1e02-4859-9257-4c82ab2691f3	2026-04-21 02:37:40.877
908af585-b754-49a6-81d8-ef7b4fd93450	d1fa0b9d-1491-4317-b8db-f922e8f586d0	2026-04-21 02:37:40.877
\.


--
-- Data for Name: Allocation; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Allocation" (id, amount, description, "targetType", "targetId", "targetName", "recordedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Announcement; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Announcement" (id, title, content, type, "targetId", "authorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Answer; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Answer" (id, "agentId", "questionId", text, "createdAt", "updatedAt") FROM stdin;
adb31940-216a-4c36-aa02-17825bf64171	908af585-b754-49a6-81d8-ef7b4fd93450	d8ef0317-d808-432b-b3d7-0cb011f740ba	Pelo Intagram	2026-04-21 00:42:32.614	2026-04-21 00:42:32.614
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AuditLog" (id, "actorId", "actionType", "actionDetail", "ipAddress", "createdAt", "actorEmail", "actorName", entity) FROM stdin;
14d44430-8fc2-4759-a351-e497cc56a41d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 15:54:21.57	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8dc89548-27c0-4aea-bf63-050e026e85a6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 15:54:21.652	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b33f473a-7cef-4391-9e9a-0feae8a6150e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 15:55:52.835	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8de59109-674f-4e68-8467-247ab179abae	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:09:16.903	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
de87d1f2-e815-4c99-98f4-9cb1a690d343	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:09:17.203	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
23e46f0a-85ea-4d7f-91ee-2f92301267dc	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:13:13.927	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
80fbebd3-b562-433c-a839-cf0103e345ab	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:13:16.787	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5d88bf5c-f325-48f8-8fd0-1c2a820c470b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:16:14.146	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0a4fab5b-cf36-46a4-b32b-8a6e80a1bb18	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 16:16:14.348	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
598efb70-ed15-4b83-9f40-905c06d7cc3e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 19:31:59.482	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a3cfdbea-ccd3-40d4-a506-c496940019f0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 19:31:59.565	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
99731ced-f5da-47d4-aa31-4ffd88d32486	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 19:35:59.493	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6d2416cc-9cb1-4d5d-9e88-4c0d22489787	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 19:38:30.533	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
76e1a2b6-a5ab-45b4-b897-5936c2c2bc48	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 19:38:30.587	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b61854af-4a2e-4023-8401-03a6259d2d1f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 22:41:15.491	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ba8f3a54-a59a-4dc3-830c-abfcf7eaec02	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 22:41:15.568	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bd16f5e0-e994-4c92-b7e1-08df4a256f84	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 22:41:26.612	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ac78bd13-44ee-4ee9-9b7f-16949398e8d2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-15 22:41:26.658	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d8430c3c-e370-45ac-8173-71b940bbde4b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 00:24:26.868	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
75ad033e-75d8-4c7f-9506-02f9470b1457	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 00:24:26.979	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
64cf9bc1-8f0c-4334-82e4-afc1f0695ef1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 00:26:55.142	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a3735f82-373a-4eea-afe3-9c97b569ec5b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 16:59:27.359	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9b209f9d-d739-4d33-952c-355c3ea9b06f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 16:59:27.5	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
17f02619-9b97-4c9f-8a11-7d64de9a4593	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:01:32.187	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7b89907d-2205-4a37-ba30-f2a2d97b057d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:02:29.256	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
219ff2a5-61e8-4bfc-8e7a-785299f9e279	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:06:29.297	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2c62910d-5046-4895-a216-913356f3c361	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:10:29.387	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
dd4b7181-8335-4b7e-bb58-189e594c328c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:27:25.515	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
114454ee-f7d9-4e90-a769-a4b9040c94a0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:29:20.69	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c12be15a-3caf-409d-90ee-0977735a3496	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 17:29:20.75	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f90dded6-b3d4-41b9-8a45-ea325b6ad3d4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:42:23.547	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4716d9db-71de-4bb5-96c8-8bab3fb16d9b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:42:23.689	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f1d69832-d18f-465d-aa58-1f78d711899d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:42:43.895	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9edee3d4-5f66-47f5-a21f-58d32cea44fc	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:42:43.948	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
61a635c4-eaf4-4f3c-b632-79ee38b160e8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:44:29.604	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
625d31ce-c815-43b7-84b6-fe76f8d5568b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:44:29.661	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ea35689c-6d10-4946-a5e2-c0ab8405abc3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:44:39.187	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0ed211f5-22f6-4f73-8d33-ac89028f9437	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:44:39.294	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c7dd2178-8ec1-4dd4-9c04-f4cc0fb3b346	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:46:43.872	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
96bbc397-f1a6-4e03-9cad-296ba4420377	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:48:39.679	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
aca7aa45-108d-4c60-86f3-79305ee589c4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:50:43.845	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
24d30ac1-55ba-4bf5-becf-8a8607f233c0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:51:52.574	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
81b7e911-d34f-436d-8c6a-b7f471f78ba0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:52:39.61	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f58271c0-8a5a-43fe-a212-e8b2f37c28ed	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:54:43.851	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f9349475-b57f-48be-b7cd-c3e4f624f19d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:56:39.634	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5aa79739-fe00-4092-8f14-edc8b88f6426	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 21:58:43.742	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a9a67a6f-eb47-4053-ba0c-2e34563b72c5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:00:39.449	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9cbf7010-a7ee-4c0f-9256-7dfafa7e6708	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:02:43.685	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
30df6292-cdcf-4aac-a3f1-afa0ad9178bc	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:04:39.501	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bf6968f3-94c1-4e45-b5a4-8a996ca04096	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:06:43.685	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e0e06bfb-2a3f-40f9-9dc0-5edf6e719aea	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:08:39.473	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d0d544de-0715-4ae7-a88a-bf2e33bb1cd0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:10:43.762	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
699aa067-7a94-4e3b-a849-868ea1fdc21c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:12:39.482	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b04dbfb6-3d4b-4772-b39b-d1895815cd36	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:14:43.761	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1d62a1f0-aa41-42b2-bc9c-22b781f5a11b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:16:39.517	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
222ac6a6-ca69-4dc4-9aa7-d84e3a084033	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:18:43.68	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9743943c-9e7e-4da5-9c41-62ef2feb0059	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:20:39.509	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fa9878dc-60ce-43cf-9b2c-4d41e10aa740	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:22:43.678	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bef6160e-4ec8-4d1a-be7f-3113b673b09f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:24:39.519	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
214d7d52-c95e-4562-87a9-ec371a6fc804	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:26:43.717	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
47edab12-6aff-4f27-b37c-c9f3c982d279	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:28:15.738	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6d0c5e24-190b-4c2c-bb17-e9cdf4fbb0a1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:28:39.604	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fe28cd39-5c94-47a8-bca8-4a97b8caeb89	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:30:43.719	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
3d280e16-1972-4965-8d19-039969e1232c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:31:08.855	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1a6288e4-649d-479b-81cc-3535e8e772d2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:31:17.84	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d61d3a19-ff3a-4f76-b8e8-825e84465b17	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:31:17.892	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0f21e3ee-0352-499a-990e-dbc4bd6734a9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:31:37.847	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fdd3dcd0-5f3c-4031-be05-c705be172a0a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:31:37.89	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
11d2197b-e97f-4ea0-88d0-b3fa9ea69831	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:34:43.769	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ce3160fc-4573-4ea3-a4f2-5168f94e781d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:38:43.833	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
543da7e6-93b8-40a4-8ac7-beb473472d72	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:42:44.159	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f5dbdebb-9244-44a2-90c6-59ffa89a2aa0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:46:43.917	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8d8fe91b-0560-4ef3-9f83-370f4270aa74	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:50:44.147	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
57e41beb-84ec-4467-b015-6105f9fa6579	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:54:43.884	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e56c2fb4-c720-4075-b49d-130f3eb7ed86	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 22:58:43.643	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
3baef11b-4257-439c-8936-e86abdf9ece6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:02:43.679	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d22f0593-8327-43d9-9991-53d0aa4db6c6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:06:43.655	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7cb5b8d4-0127-4f2c-9a3c-703cd50b5f70	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:10:43.679	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2e26ab56-2948-40e7-a750-aa23c1243fe9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:14:43.649	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4f1118cf-ef8c-4e53-9925-e725aaace1e0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:18:43.66	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
59732143-c1d0-4ed3-8f14-dc54b487df31	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:22:43.644	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
39ce8968-7dfc-4511-9fc6-a0c4ba442d82	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:26:43.639	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
cf2b5c02-5c1f-4ce3-89f7-0f475cc374b1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:30:43.644	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ed94a830-2697-4bb7-9042-1ee9ebd22e51	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:34:43.638	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6dab17a9-52e7-4e88-8992-643c711cce03	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:38:43.628	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8f03e939-fc6a-4348-b9a2-d363d8b59d5d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:42:43.652	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ddc81574-fbf6-4105-a9f0-c04481c660b2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:46:43.606	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b18447b1-ed08-4bb3-b751-10a5edee78f0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:50:43.683	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
943d7ce3-2489-4811-8656-fe2baa9e5919	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:54:43.571	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c809545b-240d-4945-99fa-9aa826dacbda	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-16 23:58:43.583	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b0559f49-5195-4412-b4eb-0980afd42158	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:02:43.579	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1be9f358-6bba-4af2-b758-c660dd853b30	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:06:43.609	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1706ea19-9d3e-425f-acf5-236b127005bd	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:10:43.568	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c7004317-2f5e-4333-8cbc-d6e8d6b1060b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:14:43.607	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
91d6b07e-385b-4212-8bef-2880ff6cb62a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:18:43.57	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0206836d-6c1a-43b8-8117-bd093bb72589	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:22:43.617	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2535c1ba-29fc-4221-aef2-f6595514b125	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:30:12.192	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
445af866-779e-4fc1-b0a5-161eea30db4f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:30:12.3	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1e49726e-35ad-4d81-b253-1e9dde32aa76	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:30:43.576	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
021c90b0-60e9-401c-b098-9218bc66e786	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:31:40.62	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
daa38fc5-a9e5-4a42-93b9-574e06692d6d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:31:40.954	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2daf6938-eb54-415f-8336-a901507f8308	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:34:12.395	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9d63f86d-c12e-425c-8536-8579cb5af93f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:34:43.583	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
926469ac-97ec-4cb0-8346-711fae9b5962	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:38:12.346	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1b175f45-b552-4eae-b286-b8aaf3f6a762	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:38:43.578	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2a0d33f2-bcf5-4745-ad3b-8603e1280738	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:41:40.937	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
50d018e3-6a18-45d5-a051-d3570ddbd3ad	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:42:12.315	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
447c683b-f3c6-4a5f-a444-ac9893dd5f5b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:42:22.454	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
48f68c6b-32da-43dc-a587-e6d38bcc0e4e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:42:43.583	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c850e70a-c9f1-4f57-9a39-d0ecfbfbc171	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:43:32.605	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
68f7191c-585c-40f1-9cf3-59a667533b0d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:46:12.412	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b29bc7c7-9307-4141-aafc-8ca2b7689cb6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:46:43.627	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
033c7b82-f364-45b5-b4ba-7e9a11a1a1d8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:50:12.493	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
660bccef-79d2-4228-bc5f-88f9159b53c4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:50:43.646	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
742b194d-6124-49b5-ac53-2409db237239	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:54:12.738	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7608b55d-d313-41a0-8996-10c6b0ec3fc4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:54:43.748	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
43220987-e987-4366-adcc-5eaa51b60100	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:58:12.485	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
17b01a8a-15c8-4509-8c0f-74551c3c7468	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 00:58:43.681	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
af648363-2d16-426c-ad25-4641500df47f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:02:12.489	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
17de081e-8f57-406c-9e2b-eb60d6645ef0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:02:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c4c6fada-9118-4740-bf61-abf353975d52	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:06:12.886	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bb2bf121-afb3-4554-a4b9-8a95689d4aa6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:06:43.69	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
acbdb538-4598-4db4-8083-d9b43e3cedbb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:10:12.487	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
dbcee5bc-f48a-44eb-a913-9de8717fe9eb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:10:43.738	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e902c8cb-fe9b-4f08-9a59-54b49f0414f7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:14:12.497	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
71ccca77-8e4e-45ce-9ff0-6ceb4ec6d0a3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:14:43.692	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4db0d685-e2ae-4cd2-96e9-ef6e57003917	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:18:12.519	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
61597920-e87f-4c17-bf4f-d92fe0d49b1d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:18:43.687	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
54244622-92b4-44ce-93db-0934ba3aa142	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:22:12.495	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1626f10a-a75c-496d-a1b6-87ef34aeac84	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:22:43.669	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0a24775d-fe2b-4c52-8b80-d44b8a39476e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:22:59.513	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
993fc906-909d-4d4d-b09d-5fe7f75f1019	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:26:12.462	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ab22ace5-3c83-4d38-a8b7-7261fc752acf	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:26:43.692	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1558de8f-668d-47e6-bac2-2788316a5d4c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:30:13.021	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4d08e82d-b207-4a02-af78-5a66a0245d62	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:30:43.66	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a57ba8db-a4ba-43f8-9d25-1fbc395e6add	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:34:43.658	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
cb8cb381-8da5-4e4e-878d-ee5d4421f2b6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:34:12.438	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
48bb69d3-0667-4cdd-8298-fb20d52ae8ff	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:38:12.517	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0f7b09a0-7df5-45e9-b631-b2f025b79f78	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:38:43.661	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5d1e6e87-c0b2-4b53-a4a3-cd7f99037ec9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:42:12.505	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fef02454-4ae4-4a24-843f-bbfe5324a690	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:42:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
aeb5e0d3-b18d-48dc-80fc-8026ce78e61d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:46:12.464	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5594acac-d63c-4ec3-8b9c-0f377c2284cd	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:46:43.649	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
82c5aef8-8550-4de7-992d-db678e6bfc9d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:50:12.45	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4708a083-3322-476b-94f1-66adb3c33e39	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:50:43.651	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6a937e43-6986-43cb-8482-284853d383d6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:54:12.576	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b2228fdd-252d-4938-9cfc-eb784449bdf2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:54:43.641	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8a85706f-6204-4779-b970-99d3c151ddcb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:58:12.423	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4c8e9023-2c49-4bcd-853e-1fb6c9cdb0c0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 01:58:43.683	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bc764c08-6624-40e1-a54b-7144994eccf1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:02:12.448	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0d8f2832-80f8-4218-b7f1-8c73e1148de0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:02:43.649	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1c84c727-8e6c-406d-8f2d-db405da760b4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:06:12.609	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b6f9277e-c14c-48c6-870b-2dd73b526402	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:06:43.635	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ebb01f16-ae67-4e79-bde2-632d01b42593	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:10:12.486	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
91eb10b2-c36c-4c72-847b-9ea712c3f7f7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:10:43.636	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e741e796-a759-4108-a4fe-fd6ef8818160	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:14:12.426	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7b4b7d6d-5ef2-45dc-8d86-b24d0b94ae74	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:14:43.676	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f50bfd8e-f87b-466a-a3b2-1b3eeff3855a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:18:12.489	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
aa70e9c3-33a8-4142-aea6-605f5bf8cb37	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:18:43.626	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b08c9fa4-63bf-4d14-aced-e82717dc380f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:22:12.416	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
69bedb46-bc11-4f5a-8dee-9be6b8fc3769	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:22:43.626	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
00d870b3-fb7e-4b6c-b3ec-8e57bee9672e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:26:12.489	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
52c170c9-cdae-4d49-85c3-15ba909ee601	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:26:43.633	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c2c21b65-6af4-4fe0-a921-78b006deb946	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:30:12.45	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
84d2e501-9e53-4f26-a830-d1f5247565a9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:30:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e3921330-3703-4512-a8df-44c4d5faeec1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:34:12.442	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9df26875-d09b-41eb-944c-a9c9267fd8a7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:34:43.632	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6de109ac-610a-4191-a633-eed13d5c0573	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:38:12.43	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d68291f3-1c01-49d9-bbcb-d9d9b6e7ef4a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:38:43.641	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e2154083-20d4-4601-8c19-683c2fd5e6b2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:42:12.517	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
dde9a98a-d178-4349-87de-72d671b5cee3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:42:43.633	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d14a906b-1f9c-42f9-a669-38c883d848b1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:46:12.426	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4c4b9a69-3103-4efd-ba0a-30533f377411	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:46:43.677	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8f88a04c-99f0-4c57-9a94-b12ecd4f7ca9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:47:40.391	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b6e58be3-87cd-4635-8b40-7b63cbac2757	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:50:12.425	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0313d224-fbe2-4255-97a4-5c36e611b2b6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:50:43.634	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d12cfe5e-5d83-49d6-95c1-6a25c6a44525	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:51:14.738	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5fd4233b-fb78-4dda-bc3f-471a3dda728d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:54:12.441	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1aab1a89-3eea-40d4-beb1-1612b75e8ccd	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:54:43.857	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
341b8464-a578-46be-be5e-7ab05fbba3af	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:58:12.52	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
522fc09e-bd85-4eff-8dfd-694152bd6509	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 02:58:43.641	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9286bef2-9034-4172-b15f-3f27a0a89911	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:02:12.448	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
47c98b59-3b0a-473e-bdec-147bec245537	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:02:43.707	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
21b891a7-989e-4430-8cfc-a6995863e03b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:06:12.695	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4288688b-8955-4495-b3bf-ac95bccf15ad	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:06:43.678	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d53815e7-2f83-44ad-9516-8951fff2aae5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:10:12.476	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e2eb31d3-422e-41f4-a548-8d0f2a5c0ab2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:10:43.688	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ee175c43-9ad0-404f-ad58-515bd2ce9a4a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:14:12.543	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
03cb002f-1193-4d02-824b-ee509d66cac3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:14:43.693	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
795c25c7-4649-46ed-8690-1aedcd9f2183	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:18:12.886	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1667ca4c-0ab9-4fce-b411-3edfccf9c4f4	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:18:43.744	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b44d0381-082a-4b70-8f49-7656227e1dca	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:22:12.52	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b881260f-94f3-4ba7-b31f-6424cda2f5a5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:22:43.722	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d9214af9-8877-4cb3-b389-9d5c7966800f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:24:58.889	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5ce1c6e9-b8b9-4b41-b5f7-7287e189cd08	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:26:43.719	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8358b401-161e-464b-8180-0bf1494a6682	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:30:43.726	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e873e7bf-4219-4563-8e31-a434774cb461	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:34:43.753	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1d00fe9f-6e0a-4ea2-8cb8-28c734e2a966	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:38:43.723	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
65cac8ae-6cd3-44b3-8884-6b77685f6ed8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:42:43.782	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7f678397-28d1-4fe8-94e6-f327f3a36d2f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:46:43.745	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a01845b7-8427-478a-b668-b2a384b1d458	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:50:43.762	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
124a4177-8088-4342-aaa9-25f6e328a4b0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:54:43.701	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b3684255-428c-422d-882a-b3692be6e5c1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 03:58:43.691	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0651de97-9fee-4ca6-a508-9579a5b34e16	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:02:43.675	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
cd4521a7-0e66-49d3-ae39-6e8ddfb84517	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:06:44.186	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
95937359-b3cc-4e03-a297-133a993f4efc	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:10:43.674	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
eec7ef23-89f2-49b0-851e-2cd893ef9d3d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:14:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6279df69-3aeb-43d3-8275-cfdbb64c533a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:18:44.572	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
984b000e-bbdc-487f-9d96-7fe421ab0ac7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:22:43.709	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b1315724-4210-447c-84fd-0a0e1e0bfb5f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:26:43.652	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
027d2a48-ab06-4961-afd1-96921227f661	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:30:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
36e2cd3c-7dcc-4337-ad38-f37052d41dcb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:34:43.657	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b1165a5c-32ce-4556-9ccf-6154ebe01a40	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:38:43.692	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
192dc605-fe2e-490c-b48b-4d625656064c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:42:43.832	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0ed87f35-cfb8-4666-82a8-a229c7443f08	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:46:43.682	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
04792e55-be69-4245-ace7-6c4ad8678bb6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:50:43.653	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
024d41d4-3107-4561-aa61-ff375928b38a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:54:43.672	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
51f93943-67da-481c-9585-d6663b6fc5bc	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 04:58:43.654	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f0391322-750b-412e-8ac0-d663f47d586e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:00:25.954	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9ddd272b-ef32-45b9-8804-ef0119ecd283	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:00:26.037	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
224b9e4b-ae34-4b81-83b8-7d29583b05d0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:02:43.708	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0dac13fd-f856-4715-9202-778973750536	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:06:43.623	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9d1825bc-9c08-4c23-b3ca-5d66073617fe	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:10:43.712	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d9bbcd24-c908-4006-86c2-cf3913b910b5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:12:27.27	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
594eefee-4d1e-44b5-9df6-eb2fb80854f7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:12:27.325	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c2bfd99a-3b5c-4861-bd35-206e2ed24e91	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:14:43.696	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
256e8e77-469a-4454-9716-26481b915e66	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:16:25.964	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2198863b-ae61-4c41-81b5-4607656273b7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:16:26.016	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e61eb60e-8d25-4e77-ace3-ceff35fd5774	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:17:51.516	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4d0c50ed-5965-4558-9278-497894bea612	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:17:51.579	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
92ad2988-bd5b-47f4-97e6-03f084d566a6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:18:43.938	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f86833a0-2a2f-46ad-bb55-fcafb5dc0464	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:22:43.65	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
750104b8-3d94-4982-9422-44862268379b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:26:15.189	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c289ff14-11ee-403f-8beb-af3eae0d2a32	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:26:15.235	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
eadf023d-6236-4ea0-84c0-911f5544dca2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:26:43.661	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7636c831-f1f0-4549-8024-f7787ca93f9a	e2824981-90ca-4693-9042-18ee9997ea57	AUDIT	Visualização do dashboard do agente.	\N	2026-04-17 05:26:57.491	\N	\N	\N
ba7e12a1-dbc3-4acd-81a9-6582df1aad84	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:30:43.683	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fe42d208-7380-4884-9185-37dd29a60b36	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:34:43.669	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c30f2627-4713-4784-926e-21f5499ed6fb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:36:06.27	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b2f235c2-ff1c-4bbc-9e18-00cb28b22514	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:36:06.353	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b02eeba8-bd30-46ff-a5b9-61c6656c3e66	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:38:43.656	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8e6cea5f-66e9-47a0-bd99-b7d8f8b4323c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:42:43.797	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8bebdee4-bf9a-4c0d-b124-d93163498f27	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:46:43.685	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4b64f90f-0d8a-4685-bd44-b447f2d2248b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:50:43.672	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6aebc712-2a2d-454a-9b7b-014d13d470e3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:54:43.697	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e8ad6612-98ff-4b8f-bb40-5b3cfca59775	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 05:58:43.719	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
19709a41-3869-44d0-a57d-c25a67a51b94	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:02:43.68	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
79a19dcf-d3d1-4201-91d6-91540faa67fb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:06:43.849	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
97ba18b7-b1f9-4ee9-8047-27be8dd07b42	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:10:43.69	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7df65783-c727-4e15-b9b4-022d3b8de5ff	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:14:43.762	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1fb4b9e3-a0fa-4acd-868c-2db464528854	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:18:43.7	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a0bf10ff-3d9c-4fc6-87fe-8b17b7df4ba6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:22:43.698	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
323c2a28-3b97-4a1d-b503-aed5a6ada5e7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:26:43.673	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1a33a528-64aa-4702-bb11-b896261e9366	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:30:43.747	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
08136ff2-35b6-47f0-b435-e936a0ef8ddf	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:34:43.668	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
095ec6c4-6599-4228-bac7-ddc52c2f35e6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:38:43.685	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
99e7a353-6742-4f32-951a-f50573839be3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:42:43.681	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f2676f86-3be6-4579-829e-d87684fc4fd8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:46:43.718	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b7f42f74-9b50-4217-9b0d-996925740f58	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:50:43.66	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
54147486-9576-48df-9fa3-60684d25ef64	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:54:43.708	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
cc4818ed-3c43-4033-b4f9-3b2b9729c08b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 06:58:43.669	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4a3df094-b78c-476f-944d-8450d47c6df6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:02:43.746	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b3626b31-caab-4a78-a65d-eb057e5fe016	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:06:43.698	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
067878ee-1f28-4a92-805e-e8c9ba573788	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:10:43.705	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
3170fd48-c523-42c1-93d4-f70f3ac0b8c0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:14:43.679	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6932cc23-b7a3-40da-b6a3-b7d0d208d8cb	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:18:44.014	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c4073399-3549-4c79-97cb-277c2852cb11	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:22:43.684	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7e3ec2d9-d4d9-4bdf-bb6d-804ea2f0e439	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:26:43.701	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0220e118-e343-4e7d-b29b-61ee3eb8aaf7	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:30:43.703	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
52a88ca9-3dcd-468d-be5c-b90c51a4da9a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:34:43.724	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d4bf81eb-071a-4b04-9454-8e459d24c2f1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:38:43.682	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
83f9704b-5a6a-4ce5-ac1c-96e049a55c23	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:42:44.032	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e9560f4a-cc13-4e32-8045-49642ecaeb33	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:46:43.676	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
bad0cb34-888f-401a-ba73-dc244ab4f0f8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:50:43.75	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9b0d453f-6375-4364-a6c4-fa3bd6b8973e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:54:43.721	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2e0d7c04-cdf2-45bc-a471-fed2f81e021f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 07:58:43.703	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
f7c48bc0-60eb-4de9-9167-ee94998ca9f3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:02:43.686	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
62542d60-fec2-4875-a7a4-3eaf203b7515	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:06:43.952	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c2a8b7b2-c2f4-49d4-8c9f-cb771758cfab	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:10:43.659	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b894232a-af79-4730-a858-b80102765c33	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:14:43.677	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c6bd6b9c-c154-4da4-b641-edb9321c9470	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:18:43.667	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2a989e72-6316-4842-bcd3-4a522671b471	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:22:43.702	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
cf3799d3-a641-4099-ad7e-def10a664e02	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:26:43.651	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
af57bf31-36b4-4555-a652-2443675f201f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:30:43.69	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
3e511265-a746-4a6c-bc53-c3ef81a4cccf	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:34:43.637	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c210ee02-d7b8-48b9-82dc-b757e68abef5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:38:43.664	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a61ab28e-a292-44c6-86e5-98c2d7d6cec2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:42:43.654	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4b19ec7a-0e66-4690-b94f-819c14b21c3e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:46:43.656	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6311b009-873c-4892-991e-9dee2cec590f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:50:43.652	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
48e6d209-b64f-4610-8458-2830e43d3376	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:54:43.916	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
11024f32-ddbc-4d9c-83d8-ed2a1b178d96	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 08:58:43.637	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5c480210-3f8b-40b6-bb8f-68e3248ae5c0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:02:43.654	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
23bad752-786e-4f32-a7df-91f00a9f16ea	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:06:43.659	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
2e19446f-7df1-407b-afc3-354ec843aaf0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:10:43.694	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7305637a-96fa-4ae8-9927-df06d7e86a8c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:14:43.658	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6e5c2a7c-ac24-4f97-b1e4-263a548ac254	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:18:43.705	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
67a20e4b-cf65-4176-8820-3f20bb0d10ae	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:22:43.679	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
11513b34-3bcd-46ce-aadf-798f1a63a529	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:26:43.739	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
312ca141-8b67-4954-8fb7-ff114fff9be2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:30:43.718	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
30993aa8-3d2a-4243-b273-3c8e807713bd	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:34:43.716	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9ab39d52-9e85-4216-8a74-a760b4544923	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:38:43.706	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
dad5c9a2-7d65-488a-8ff8-164e809943d6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:42:43.969	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e3751af4-57f7-469e-b6f6-c8f30302a5c8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:46:43.729	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
eac401a2-6e57-411f-8db6-6e7c85fa4678	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:50:43.701	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
99a72a3d-d96f-4e17-b2f2-68ffbeac1644	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:54:43.682	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
987489af-6c40-4c22-adbf-cc892ed2a768	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 09:58:43.746	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
16560b25-9db0-430e-8d01-7664737e5918	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:02:43.645	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9eb1c59a-b63a-4a3b-919c-994fc5ad89ac	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:06:43.718	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1cec62f5-76b1-4cbc-9e53-d90b61415b28	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:10:43.66	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
33276cf3-782a-4b42-b7ea-e5477fc5ccb9	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:14:43.715	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
51e652e8-ff7b-4f48-b5b6-409ebb61ebd5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:18:43.842	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6bfe0189-c910-4157-9606-96844a884d55	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:22:43.652	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c8086ca5-c784-4570-afd6-f0cea05e36b6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:26:43.658	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
460ec70b-85be-4866-8a6b-d0fa10819f54	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:30:43.808	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6eef4d26-5a2b-4211-aa45-27f486d8e4d1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:34:43.684	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
aa168c64-7900-4dcf-9363-a71dd9a3691c	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:38:43.708	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9158c888-eb45-48c9-9a9b-b895229b975f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:42:43.722	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
daf21f74-1da9-4950-806f-6d3a97f8edd3	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:46:43.778	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8c622b24-9338-4ff4-9098-a4334d435f5d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:50:43.707	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
74088242-75ec-4717-85d6-8ea9a35131f5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:54:41.886	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
529a395d-6c68-4560-a984-65251301cf89	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:54:41.964	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ab4576c5-ff65-43e6-888b-8c89629d359d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 10:54:46.094	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
aa2292f6-9859-45c6-993c-7329f76bde7d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 16:27:54.745	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ae13144e-65ac-4d3d-b96d-621578213276	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 16:27:54.89	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
41632fe3-af88-4fc6-b7b6-5a3facfe6a5d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 16:41:57.768	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6a2fac4e-ff4d-4670-bb35-6e9c5c715eef	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-17 16:41:57.87	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6029ab45-7699-4e14-8279-23f1a8b58d3a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 12:41:09.983	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b01748cb-f68c-4546-a42e-4ee0774f8cf0	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:16:29.293	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d9e94b43-bda4-474a-97fa-cfea9a0c8a79	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:16:29.436	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6a3c3da1-1aa8-4623-8869-fe222193114b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:16:29.513	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a83407f5-cc74-4dd9-9ba3-0eaa0ab8946d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:55:05.578	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e0d74175-e8d5-48a7-a464-31802557076b	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:55:05.899	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
7d0f3b6a-3268-44ab-86fb-14b0f61a88c2	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:57:24.011	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
53d2db6d-af2c-4047-bff7-871436b2593a	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-18 22:57:24.262	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
b352d499-e6a7-4122-8eb1-5244a2fdd03d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-19 13:17:35.627	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
e1ad42c8-c12d-4c4c-a1de-8aefc4d1fe1e	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-19 13:17:35.711	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
ef59d4a8-e88e-47a1-8659-ea7a9c810cac	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:07:00.974	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
4c0fcfa9-90c8-4fed-b17f-98b71bfbda28	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:07:27.312	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
a967398a-cb14-4f07-bee0-aa4731f559a0	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:08:22.026	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
46afe722-879c-4c88-9e91-86981bcf113c	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:13:25.604	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
8e0c7f0d-4e00-4fbc-b921-be906da9edd9	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:17:01.011	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
d9076a98-9935-47ed-abc8-81eb92db6813	c807bee5-8673-43a2-a00c-be056c5e0836	AUDIT	Visualização do dashboard do agente.	\N	2026-04-15 16:18:51.761	youcanpublicidade@gmail.com	Leticia Siqueira de Paula Albuquerque	\N
532d79c9-ba97-4579-acdf-0242035ab42a	bdaa913b-7418-4fd9-af83-e7538d3cbf7f	AUDIT	Visualização do dashboard do agente.	\N	2026-04-17 13:14:45.725	murilaliberato@gmail.com	Murila Oliveira Liberato	\N
2bf4282a-2d80-4f47-b8f1-550ac5634673	bdaa913b-7418-4fd9-af83-e7538d3cbf7f	AUDIT	Visualização do dashboard do agente.	\N	2026-04-17 13:15:57.187	murilaliberato@gmail.com	Murila Oliveira Liberato	\N
e1cfdba6-ae5f-48ab-a4df-dbb1b9606371	bdaa913b-7418-4fd9-af83-e7538d3cbf7f	AUDIT	Visualização do dashboard do agente.	\N	2026-04-17 13:16:31.461	murilaliberato@gmail.com	Murila Oliveira Liberato	\N
5f7f2b58-39da-4915-8f20-4de3ec79c5ff	cb24c29d-ba9f-493e-9ab5-84b3b9f61c67	AUDIT	Visualização do dashboard do agente.	\N	2026-04-18 01:17:55.525	abcsarahkbenavides@gmail.com	Sarah Katherine Benavides Alvarez	\N
815b23cc-b698-4c33-91bf-4f11c5428351	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-18 12:46:39.795	leticiasiq027@gmail.com	Letícia Albuquerque	\N
43b9ed4e-90dc-43db-a023-3671ffbab166	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-18 12:47:28.782	leticiasiq027@gmail.com	Letícia Albuquerque	\N
172885b3-52bb-40fc-805d-77997f4f9fbf	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-19 15:33:47.246	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
df9c37a2-8655-4a73-b4d4-6b36882e8f85	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-19 15:33:47.31	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
9616e786-6350-46f8-8ae0-27d5f4d706f0	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:39:12.213	leticiasiq027@gmail.com	Letícia Albuquerque	\N
9715af17-6856-4576-a7db-d1d1741b6a65	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:41:13.436	leticiasiq027@gmail.com	Letícia Albuquerque	\N
bf746a99-642a-4efd-a21a-92a8818e6b20	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:43:12.035	leticiasiq027@gmail.com	Letícia Albuquerque	\N
dacb6749-6578-4623-ac05-8fac5825f232	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:47:12.047	leticiasiq027@gmail.com	Letícia Albuquerque	\N
048ea91a-6410-4283-8974-90840cda284e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:51:12.478	leticiasiq027@gmail.com	Letícia Albuquerque	\N
e1c0cec4-beaa-4aa2-8730-2ba92884da1b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:55:12.497	leticiasiq027@gmail.com	Letícia Albuquerque	\N
8e1edca6-19ce-4ff8-9265-61ec1693baa1	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 15:59:12.46	leticiasiq027@gmail.com	Letícia Albuquerque	\N
73d65609-5348-4d20-a9b9-ba04c621ac7a	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:03:12.54	leticiasiq027@gmail.com	Letícia Albuquerque	\N
a53660fa-b38e-44b1-b214-fdec82011c38	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:07:12.461	leticiasiq027@gmail.com	Letícia Albuquerque	\N
a176cdf9-1500-457e-a2c5-6106023d2f87	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:11:12.498	leticiasiq027@gmail.com	Letícia Albuquerque	\N
07a96c57-3eca-4fb0-9aed-f88502941337	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:15:12.537	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ac42d2b3-0d0a-464a-a809-8c1e4298c1f3	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:19:12.478	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ef83907f-6bad-4079-a14b-a564f8a09e3d	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:23:12.466	leticiasiq027@gmail.com	Letícia Albuquerque	\N
58406cac-1a17-4cd5-8c10-c3ce601666eb	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:27:12.511	leticiasiq027@gmail.com	Letícia Albuquerque	\N
be5e3f28-a840-4305-aa1c-39cc7a4abef6	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:31:12.461	leticiasiq027@gmail.com	Letícia Albuquerque	\N
40801c8b-c190-42ee-8179-ffa44840752b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:35:12.517	leticiasiq027@gmail.com	Letícia Albuquerque	\N
82391abe-f23e-4fd3-a019-9b6b6f9e9481	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:39:12.5	leticiasiq027@gmail.com	Letícia Albuquerque	\N
bf596f85-9355-4d48-99c6-d9123b8edc46	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:43:12.565	leticiasiq027@gmail.com	Letícia Albuquerque	\N
e46f65b2-70be-4437-b62b-617bba6bd70d	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:47:18.363	leticiasiq027@gmail.com	Letícia Albuquerque	\N
76731c89-5f0a-4d3e-b51a-0512303a0e84	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:51:12.672	leticiasiq027@gmail.com	Letícia Albuquerque	\N
5574f8c3-2283-4d33-9935-a0ca8c341e22	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:55:12.515	leticiasiq027@gmail.com	Letícia Albuquerque	\N
571cc1be-fef1-4cc5-abd4-2aa1cff0f484	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 16:59:12.566	leticiasiq027@gmail.com	Letícia Albuquerque	\N
9acf7139-c885-4476-bc05-45ff92413386	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:03:12.724	leticiasiq027@gmail.com	Letícia Albuquerque	\N
28955a89-9730-48d3-96da-bd333782847b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:07:12.537	leticiasiq027@gmail.com	Letícia Albuquerque	\N
1375d7bb-09a4-46fd-be1b-d6cdfa8b32b2	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:11:12.523	leticiasiq027@gmail.com	Letícia Albuquerque	\N
b99515b6-9044-43e7-be5c-955beac943e1	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:15:12.652	leticiasiq027@gmail.com	Letícia Albuquerque	\N
41d44f2b-3884-46f5-ac79-cf6360836d68	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:19:12.492	leticiasiq027@gmail.com	Letícia Albuquerque	\N
06705b9b-3296-428f-80fa-95d3b6384b59	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:23:12.502	leticiasiq027@gmail.com	Letícia Albuquerque	\N
5f4d9c61-00b8-4970-a152-ea49ce99c799	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:27:12.505	leticiasiq027@gmail.com	Letícia Albuquerque	\N
bfecbd98-bc87-4f81-b8ce-8ded1fedb714	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:31:12.547	leticiasiq027@gmail.com	Letícia Albuquerque	\N
9396b00a-63af-4863-90ab-31412f8797de	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:35:12.484	leticiasiq027@gmail.com	Letícia Albuquerque	\N
f50f3e56-2bfb-4d90-a557-cbe768ed9ef2	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:39:12.531	leticiasiq027@gmail.com	Letícia Albuquerque	\N
4e16b410-dfb7-45ff-913a-ed33f07d6408	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:43:12.492	leticiasiq027@gmail.com	Letícia Albuquerque	\N
469eb535-bff6-4974-a151-fffa684ae001	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:47:12.54	leticiasiq027@gmail.com	Letícia Albuquerque	\N
d34d6ad9-5580-4f40-a5c5-c9189ac4087e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:51:12.539	leticiasiq027@gmail.com	Letícia Albuquerque	\N
06208b8e-bc43-4ba4-8141-f545a73184e5	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:55:12.507	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ee3a36f1-04a9-40d9-b934-5e0a4eae6d75	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 17:59:12.486	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6028f6bc-5eba-4d49-855f-f04468557e6e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:03:12.812	leticiasiq027@gmail.com	Letícia Albuquerque	\N
a00960b6-935d-42ee-8982-a8933c4d8705	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:07:12.49	leticiasiq027@gmail.com	Letícia Albuquerque	\N
3d03563b-5ea9-41a3-affb-b909d357e788	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:11:12.511	leticiasiq027@gmail.com	Letícia Albuquerque	\N
4836b808-94c0-41a7-a062-96adca02028d	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:15:12.513	leticiasiq027@gmail.com	Letícia Albuquerque	\N
923237fb-f3e9-4b08-9f0d-f21db2d57105	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:19:12.556	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2951e6aa-d6d2-4092-9eb6-76bfbd7054df	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:23:12.472	leticiasiq027@gmail.com	Letícia Albuquerque	\N
741bd4b2-7af6-4811-8e23-e5f60e04870c	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:27:12.493	leticiasiq027@gmail.com	Letícia Albuquerque	\N
4495cba3-c891-4b2f-81b2-757f10e4211e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:31:12.457	leticiasiq027@gmail.com	Letícia Albuquerque	\N
da19dac4-96c6-4add-a12e-58fda0b813e0	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:35:12.502	leticiasiq027@gmail.com	Letícia Albuquerque	\N
fbe1b336-37e6-48ba-8036-9a4fd0ad8909	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:39:12.519	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ef37694e-0995-4639-a999-aa10e156a236	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:43:12.466	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6f3604d8-459e-47cb-a986-3ee34a624410	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:47:12.447	leticiasiq027@gmail.com	Letícia Albuquerque	\N
45a7b559-1404-436d-a1ca-edf02dea17a5	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:51:12.528	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6e5d9506-98fe-4ac1-8c95-4de3a1ff126f	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:55:12.478	leticiasiq027@gmail.com	Letícia Albuquerque	\N
27289b7f-b3c0-4cb6-9e75-6a4ae614078f	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 18:59:12.511	leticiasiq027@gmail.com	Letícia Albuquerque	\N
c3438e58-f45f-4756-80fa-190dbd3b5116	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:03:12.523	leticiasiq027@gmail.com	Letícia Albuquerque	\N
d8ba0c82-90c8-4088-acb3-f4a58927b8cd	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:07:12.546	leticiasiq027@gmail.com	Letícia Albuquerque	\N
52745e85-b5b6-444e-aaf4-662e7fafac76	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:11:12.511	leticiasiq027@gmail.com	Letícia Albuquerque	\N
b355c452-73a0-40bc-88b8-76010b21f7f5	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:15:12.561	leticiasiq027@gmail.com	Letícia Albuquerque	\N
1a13cd54-6976-450b-9df7-57be73592d90	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:19:12.527	leticiasiq027@gmail.com	Letícia Albuquerque	\N
dd472a4d-19cf-45ab-8c9b-eaf5cd70de49	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:23:12.571	leticiasiq027@gmail.com	Letícia Albuquerque	\N
dba4a94d-6430-457b-9b08-c4525d5c77bc	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:27:12.587	leticiasiq027@gmail.com	Letícia Albuquerque	\N
3766f4aa-d9b9-495a-8869-a7c4d761ea60	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:31:12.515	leticiasiq027@gmail.com	Letícia Albuquerque	\N
0146f58b-e4b1-4840-9b68-94106cdda9f3	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:35:12.487	leticiasiq027@gmail.com	Letícia Albuquerque	\N
b3b9d07a-baff-4027-aaa4-7662355ca1f8	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 19:37:15.938	leticiasiq027@gmail.com	Letícia Albuquerque	\N
10190a37-71a5-4beb-a9ef-dc3cdf5bc325	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 21:42:18.665	leticiasiq027@gmail.com	Letícia Albuquerque	\N
e5ca4492-5d70-4fa6-abfb-96296a7a4ec3	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 22:37:21.009	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ff85e1b0-a494-4837-9983-018d81aa32e5	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-19 22:37:24.644	leticiasiq027@gmail.com	Letícia Albuquerque	\N
d50eb04d-dc89-4aab-8f41-251732731a77	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 06:20:02.287	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
6743a99d-4c9c-465b-afe1-d01d4ff8f069	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 06:20:02.374	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
28d05f09-f01b-40bd-8628-fed4df99e8d8	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-20 06:36:45.247	leticiasiq027@gmail.com	Letícia Albuquerque	\N
42f49d2e-8231-4d6f-97e8-f9d4cde3edbe	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 06:41:02.074	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
116fb3ae-e5ed-447d-bfbf-516eb57f0dca	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 06:41:02.268	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
10229f8e-4ac3-46fb-aa21-5c756133abf5	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 06:43:46.797	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
c45dd239-f999-4f1f-aa2b-fcd88dc61d56	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:39:59.037	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
05941630-773c-4e2a-81d8-5d134a76dc56	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:39:59.127	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
0c3b59f7-ea3f-4eea-b268-a28450e33248	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:43:59.013	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d8e91efe-0689-4b90-90ab-aba13cd75162	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:47:58.964	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
a7983237-84b2-4bf8-9e5e-eeba38cc178f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:51:16.879	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
80c1e992-111c-451e-a84d-37eb857d45df	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:51:16.944	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
1bb014bb-fa9d-4743-89f7-67b9e2fb4b32	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:55:16.898	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5eaee083-e704-47fd-a7df-c45c4c4feaf6	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 11:59:17.935	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
63124d9b-a830-4529-beff-6d6498f12780	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 12:03:18.085	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
01ddc9b7-892d-4b1b-b93d-75928480b968	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 12:03:26.651	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
50d08123-03a3-4f58-af46-c73f8811cb55	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 22:29:42.771	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
8babb9a6-98cf-41a4-ab58-a523784096f1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 22:29:42.846	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
4f3059be-62f8-48cf-ad8f-88bce435aae8	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 23:53:02.518	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
fd17b178-0ab4-43ca-af52-21f56212a170	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 23:53:43.759	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
3e8d517f-1771-4226-98ae-a64b467dcf4d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-20 23:57:43.81	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
60af1a8f-2d9f-449b-b1d7-4fc58c2ff800	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-21 00:01:01.885	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
5700584d-e08f-4743-8045-f24c1f388dbc	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:06:30.013	leticiasiq027@gmail.com	Letícia Albuquerque	\N
eb34cd16-9d0c-4458-b6e1-8ed9c085ceb2	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:13:17.054	leticiasiq027@gmail.com	Letícia Albuquerque	\N
d8486163-7dc8-48e6-9d5d-15ce66f86734	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:24:12.076	leticiasiq027@gmail.com	Letícia Albuquerque	\N
f8102a68-b190-4b2a-902a-f504f5b80a8a	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:26:12.723	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ebb284d6-6d32-4899-848b-00ab160e0722	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:26:28.781	leticiasiq027@gmail.com	Letícia Albuquerque	\N
78f6c536-ebaa-4807-9edc-5820af573427	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:26:41.085	leticiasiq027@gmail.com	Letícia Albuquerque	\N
cc2ecf8f-bfa8-48e1-94f5-7f732e0de30e	78175a82-44aa-4a8a-afca-0914b8d68c6f	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:32:42.841	internal@globusdei.local	Internal Service	\N
3e106d70-0115-4905-aae7-86da39cf2512	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:34:05.684	leticiasiq027@gmail.com	Letícia Albuquerque	\N
1553fa3f-956f-4cbf-917d-97bf7e6ca340	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:34:25.716	leticiasiq027@gmail.com	Letícia Albuquerque	\N
c2f82424-9ee9-4872-bad5-3e99f00846ce	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:35:09.28	leticiasiq027@gmail.com	Letícia Albuquerque	\N
1a251cd2-71d6-436d-b49d-47492993c2df	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:35:20.569	leticiasiq027@gmail.com	Letícia Albuquerque	\N
360c42c7-2d05-4db6-a1b9-8be471831a65	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:36:04.056	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2c8b3736-9eab-4212-a7ae-d0259e4f845a	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:35:44.336	leticiasiq027@gmail.com	Letícia Albuquerque	\N
72208aee-7a7f-4ad2-beb6-1a8ade50754e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:37:36.791	leticiasiq027@gmail.com	Letícia Albuquerque	\N
61e3869c-0549-45ed-8a23-3afcbbce6cf0	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:38:54.623	leticiasiq027@gmail.com	Letícia Albuquerque	\N
50c01f90-7d09-41cf-9514-deaafba6c8c1	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-21 00:41:02.139	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
d6d6a3be-53f2-4484-84e5-5d03364c2c5d	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Visualização do dashboard do colaborador.	\N	2026-04-21 00:41:02.223	albuquerque0127@gmail.com	Administrador GlobusDei	Collaborator
97d0f16f-7814-4556-b6da-216878a748c1	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:41:52.026	leticiasiq027@gmail.com	Letícia Albuquerque	\N
49697f7d-d2d9-4f8d-bc9c-9408cdf12bfe	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Submissão do onboarding.	\N	2026-04-21 00:42:32.622	leticiasiq027@gmail.com	Letícia Albuquerque	\N
a2319f49-26ad-40c4-8189-d326084ac223	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Aprovação do questionário do agente 908af585-b754-49a6-81d8-ef7b4fd93450.	\N	2026-04-21 00:42:48.604	albuquerque0127@gmail.com	Administrador GlobusDei	\N
0cf094b9-69c1-496d-a2e0-1ec7c51c8e29	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Agendamento do slot 494ac3ea-510e-4db2-8c99-87bbf3613769.	\N	2026-04-21 00:43:32.698	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ed19c3d5-48e1-4441-863e-dbbd8dd6a62f	f4c7f164-34ef-4255-b5be-3083f1d70897	AUDIT	Feedback do onboarding do agente 908af585-b754-49a6-81d8-ef7b4fd93450.	\N	2026-04-21 00:44:05.509	albuquerque0127@gmail.com	Administrador GlobusDei	\N
86cefb07-6502-4cb4-9dd5-d7ee6737f0f0	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:44:25.425	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ee68b1fe-1dcb-45bd-9de9-e6c6373df287	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:44:45.329	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2bca6b76-4e07-4e4c-bc88-1b403713c3f1	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 00:49:19.518	leticiasiq027@gmail.com	Letícia Albuquerque	\N
f06f0b4e-c3a3-4c49-be79-2038eff3a5ce	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:52:33.991	leticiasiq027@gmail.com	Letícia Albuquerque	\N
94b865e4-0bc9-42ab-8745-8b55bdbd4ae6	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:55:35.599	leticiasiq027@gmail.com	Letícia Albuquerque	\N
3d51f01d-8856-40f0-bc2e-9e6f4eab93b2	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:57:13.776	leticiasiq027@gmail.com	Letícia Albuquerque	\N
f89dc2b6-9f39-4316-877b-1d29a449e63b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:58:57.301	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6143d366-dbd4-4a30-a10c-cd9de5b3164b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 00:59:34.105	leticiasiq027@gmail.com	Letícia Albuquerque	\N
ff214464-5dac-4ae2-af9d-579b60f67c54	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:00:07.144	leticiasiq027@gmail.com	Letícia Albuquerque	\N
7e137139-b2b4-4e4c-be94-f5f0886b3a82	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:00:28.523	leticiasiq027@gmail.com	Letícia Albuquerque	\N
9133e1d5-27ee-40bd-868f-0b512c56d89b	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:02:05.703	leticiasiq027@gmail.com	Letícia Albuquerque	\N
96868387-90be-4928-82af-31a70ad7d7af	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:02:27.904	leticiasiq027@gmail.com	Letícia Albuquerque	\N
9e6ccb81-d9e0-43dc-a4e5-85252a614ad5	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:02:33.999	leticiasiq027@gmail.com	Letícia Albuquerque	\N
d4a49548-dbfa-490e-a9cc-384dbd8ea7bd	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:02:49.656	leticiasiq027@gmail.com	Letícia Albuquerque	\N
4fe896bc-9a1b-4b52-83ae-1dcc1300febe	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:03:00.409	leticiasiq027@gmail.com	Letícia Albuquerque	\N
18031b78-6f99-4617-b4ec-30722e9720c2	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 01:03:08.846	leticiasiq027@gmail.com	Letícia Albuquerque	\N
32d03a17-efc8-4cc9-91a1-37d74f41c58e	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:35:06.34	leticiasiq027@gmail.com	Letícia Albuquerque	\N
287b3992-fda0-42d8-ab9b-d441cbfe120a	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:35:31.855	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6df26591-1a18-4454-9084-9a86b8680f0c	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:35:32.84	leticiasiq027@gmail.com	Letícia Albuquerque	\N
98600a3d-028b-48e7-899a-5499e1a58021	1755740e-d299-4da8-bba6-5c4ad52f0cc6	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:36:51.241	s.isadora@ufms.br	ISADORA DA SILVA DOS SANTOS	\N
ae9dd3d1-3edf-4824-9ad0-245ee6a803f3	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:37:07.096	leticiasiq027@gmail.com	Letícia Albuquerque	\N
07eb8d26-1bcc-45b5-bd2f-07c98c0ceed3	908af585-b754-49a6-81d8-ef7b4fd93450	TECHNICAL	Atualização do perfil do agente.	\N	2026-04-21 02:37:40.892	leticiasiq027@gmail.com	Letícia Albuquerque	\N
57479737-86bf-42a4-a74a-cbc035502ece	1755740e-d299-4da8-bba6-5c4ad52f0cc6	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:38:06.109	s.isadora@ufms.br	ISADORA DA SILVA DOS SANTOS	\N
0cd9d74e-a991-4255-b7b1-525d09c51f05	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:38:39.87	leticiasiq027@gmail.com	Letícia Albuquerque	\N
044745e2-306b-4737-9ecf-463ddfa61bd2	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:39:06.858	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2feb09ce-b639-4e08-8812-e815f06fbd32	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:39:23.114	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2a55c266-582c-4801-93e1-d567fd68b776	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:39:31.822	leticiasiq027@gmail.com	Letícia Albuquerque	\N
1240cff9-eb99-4da6-ac64-39fbaf80c04a	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:39:32.849	leticiasiq027@gmail.com	Letícia Albuquerque	\N
2258fdbd-8283-45b9-9374-6d6be0052a21	a37d959d-0f0a-4c99-b362-2dab0e468cd8	AUDIT	Pedido de oração criado: cdbd2175-121f-4b0a-a945-f96a6ffa09cd	\N	2026-04-21 02:39:54.674	leticiasiq027@gmail.com	Letícia Albuquerque	\N
5d4476b3-074b-471f-b960-2bad17ca0939	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:39:58.377	leticiasiq027@gmail.com	Letícia Albuquerque	\N
7654cf33-02fc-416d-aba6-c3be2707b914	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:40:08.83	leticiasiq027@gmail.com	Letícia Albuquerque	\N
868f8818-8847-4713-881a-2654c3fc0ef1	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:41:24.547	leticiasiq027@gmail.com	Letícia Albuquerque	\N
6b411b6b-0bb2-4e2f-83e5-521f1df5a354	908af585-b754-49a6-81d8-ef7b4fd93450	AUDIT	Visualização do dashboard do agente.	\N	2026-04-21 02:41:25.313	leticiasiq027@gmail.com	Letícia Albuquerque	\N
7038ef71-f1bf-4279-9f5b-4fa1d080872d	a37d959d-0f0a-4c99-b362-2dab0e468cd8	AUDIT	Visualização de dados do agente 1755740e-d299-4da8-bba6-5c4ad52f0cc6.	\N	2026-04-21 02:50:46.32	leticiasiq027@gmail.com	Letícia Albuquerque	\N
fcdee378-e7b8-4aa0-8e13-681546c2bbd3	a37d959d-0f0a-4c99-b362-2dab0e468cd8	AUDIT	Visualização de dados do agente 1755740e-d299-4da8-bba6-5c4ad52f0cc6.	\N	2026-04-21 02:51:06.193	leticiasiq027@gmail.com	Letícia Albuquerque	\N
\.


--
-- Data for Name: AvailabilitySlot; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."AvailabilitySlot" (id, "startTime", "endTime", "collaboratorId", "meetLink", "createdAt", "updatedAt") FROM stdin;
494ac3ea-510e-4db2-8c99-87bbf3613769	2026-04-20 08:00:00	2026-04-20 09:00:00	f4c7f164-34ef-4255-b5be-3083f1d70897	\N	2026-04-21 00:43:23.402	2026-04-21 00:43:23.402
\.


--
-- Data for Name: Collaborator; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Collaborator" (id, "authSubject", name, email, "isActive", roles, "expertiseAreas", notes, "createdAt", "updatedAt") FROM stdin;
06dfae3b-b513-49ad-94e3-1636e6fb4e72	cdd358d4-9443-4fab-80b1-93f5036104b3	Murila Oliveira Liberato	murilaliberato@gmail.com	t	{}	{}	\N	2026-04-17 13:13:23.891	2026-04-17 13:15:56.868
f4c7f164-34ef-4255-b5be-3083f1d70897	45793d1a-268f-4a49-aacb-05c28957b947	Administrador GlobusDei	albuquerque0127@gmail.com	t	{ADMIN}	{}	\N	2026-04-15 15:34:35.948	2026-04-21 00:56:07.969
9ad19ce0-9059-4460-9353-a81340856c3d	dc675cd2-e710-4158-9116-a4d5123e5f70	ISADORA DA SILVA DOS SANTOS	s.isadora@ufms.br	t	{}	{}	\N	2026-04-21 02:36:50.885	2026-04-21 02:36:50.885
143407d6-b2ac-4fcd-90b3-e8fb0f60863b	afe2798d-82ca-492b-863e-257ae3162319	Sarah Katherine Benavides Alvarez	abcsarahkbenavides@gmail.com	t	{}	{}	\N	2026-04-17 10:35:26.691	2026-04-17 10:35:26.691
d19c0606-3161-4ddc-8e67-73df2883b5f8	a37d959d-0f0a-4c99-b362-2dab0e468cd8	Letícia Albuquerque	leticiasiq027@gmail.com	t	{}	{}	\N	2026-04-18 12:44:29.51	2026-04-21 02:40:08.714
\.


--
-- Data for Name: Connection; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Connection" (id, "senderId", "receiverId", status, "createdAt", "updatedAt") FROM stdin;
59871d58-6461-4031-9ea8-0879c8e1fd9c	908af585-b754-49a6-81d8-ef7b4fd93450	c807bee5-8673-43a2-a00c-be056c5e0836	PENDING	2026-04-18 12:46:29.929	2026-04-18 12:46:29.929
acca58b4-ed07-4a37-8582-c73f93b52aed	908af585-b754-49a6-81d8-ef7b4fd93450	01398710-93a0-49e3-851d-f672dc90a0eb	PENDING	2026-04-21 02:38:51.269	2026-04-21 02:38:51.269
3b9b77cc-1944-40ec-a9c5-11c3bbebc336	908af585-b754-49a6-81d8-ef7b4fd93450	1755740e-d299-4da8-bba6-5c4ad52f0cc6	PENDING	2026-04-21 02:38:52.466	2026-04-21 02:38:52.466
ab95c686-f92b-4bd0-b902-44b130dc1389	908af585-b754-49a6-81d8-ef7b4fd93450	78175a82-44aa-4a8a-afca-0914b8d68c6f	PENDING	2026-04-21 02:38:54.732	2026-04-21 02:38:54.732
8c550300-9600-47df-b1b1-0cb1f8610439	908af585-b754-49a6-81d8-ef7b4fd93450	bdaa913b-7418-4fd9-af83-e7538d3cbf7f	PENDING	2026-04-21 02:38:58.166	2026-04-21 02:38:58.166
204f3fa3-a6b2-47e9-8267-1ed5ea6e0f60	908af585-b754-49a6-81d8-ef7b4fd93450	0ff72fb8-4043-44d9-b488-62ead5123434	PENDING	2026-04-21 02:38:58.99	2026-04-21 02:38:58.99
a39945ed-4eb9-4611-b9fc-2c75f69145a7	908af585-b754-49a6-81d8-ef7b4fd93450	cb24c29d-ba9f-493e-9ab5-84b3b9f61c67	PENDING	2026-04-21 02:39:00.478	2026-04-21 02:39:00.478
b619e0c1-9cca-45ba-8d76-fd4ab339e310	908af585-b754-49a6-81d8-ef7b4fd93450	f5a295ab-14d2-4d37-9d4d-d08a4f9396ac	PENDING	2026-04-21 02:39:01.286	2026-04-21 02:39:01.286
\.


--
-- Data for Name: Empreendimento; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Empreendimento" (id, name, description, "establishedDate", type, category, "socialLinks", "portfolioUrl", location, "actuationRegions", "logoUrl", "bannerUrl", "monthlyExpenses", "incomeSources", "needType", "receivesInvestments", "isBankVerified", "bankDetails", "priorityScore", "followUpStatus", "internalNotes", "internalResponsibleId", "ownerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmpreendimentoFollow; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."EmpreendimentoFollow" ("agentId", "empreendimentoId", "createdAt") FROM stdin;
\.


--
-- Data for Name: EmpreendimentoInvite; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."EmpreendimentoInvite" (id, "empreendimentoId", email, role, status, token, "inviterId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmpreendimentoMember; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."EmpreendimentoMember" ("agentId", "empreendimentoId", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Event" (id, title, description, date, location, "isOnline", "isCancelled", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EventRsvp; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."EventRsvp" (id, "eventId", "agentId", confirmed, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ExpenseCategory; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."ExpenseCategory" (id, name, description, "entryType", "createdAt", "updatedAt") FROM stdin;
ff9b1f8d-0ba9-4d38-9f3c-ac8109dd3a90	Doação	Doação voluntária	INCOME	2026-04-17 03:27:46.063	2026-04-17 03:27:46.063
8737cf41-cea0-4032-b8d0-8ba34aef322e	Apoio Empresarial	Investimento de empresas parceiras	INCOME	2026-04-17 03:30:17.847	2026-04-17 03:30:17.847
e902633b-738d-4297-a772-4ee1ce9bd00f	Aporte único	Investimento feito uma única vez	EXPENSE	2026-04-17 03:37:06.93	2026-04-17 03:37:06.93
163c39f1-c399-44f5-959b-46dd9b8c0757	Aporte temporário	Investimento por tempo estabelecido	EXPENSE	2026-04-17 03:37:39.516	2026-04-17 03:37:39.516
812a946a-1183-41cb-854b-5d73004a4163	Bolsa missionária	Patrocínio de estudos missionários	EXPENSE	2026-04-17 03:38:43.545	2026-04-17 03:38:43.545
131413fa-704e-43c2-b334-13c03b80d624	Manutenção	Valores para manutenção da organização	EXPENSE	2026-04-17 03:39:45.578	2026-04-17 03:39:45.578
04a025dc-2525-499b-a8e8-404aa3f21adc	Doação temporária	Doações por tempo estabelecido	INCOME	2026-04-17 03:40:39.897	2026-04-17 03:40:39.897
\.


--
-- Data for Name: ExperienceType; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."ExperienceType" (id, name, description, "createdAt", "updatedAt") FROM stdin;
c3472cf9-1ede-4577-8987-f1a45d0d05ce	Missionária	Atuação direta no campo missionário	2026-04-20 23:49:20.509	2026-04-20 23:49:20.509
0c8be6ba-0562-42ab-ab4a-16f4075aa69e	Profissional	Experiência no mercado de trabalho secular	2026-04-20 23:49:20.514	2026-04-20 23:49:20.514
55c0b882-17ee-4865-8ec1-478a8f733fc6	Ministerial	Atuação em igreja local (pastorado, louvor, etc)	2026-04-20 23:49:20.517	2026-04-20 23:49:20.517
701b5bbc-c971-4684-84ce-e2a41c8a258d	Acadêmica	Experiência em ensino, pesquisa e universidade	2026-04-20 23:49:20.519	2026-04-20 23:49:20.519
feb52bb5-1007-45c9-8848-4fc23edc2e5f	Iniciativas	Projetos independentes ou empreendedorismo	2026-04-20 23:49:20.521	2026-04-20 23:49:20.521
b1d9a877-6cf4-4abe-b5e8-b2316bbb1879	Voluntariado	Ações contínuas de serviço sem remuneração	2026-04-20 23:49:20.523	2026-04-20 23:49:20.523
eea278c1-8b52-4688-9860-c8b35d471a78	Organização	Experiência organizacional/administrativa em ONGs ou Agências	2026-04-20 23:49:20.525	2026-04-20 23:49:20.525
\.


--
-- Data for Name: FinalWork; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."FinalWork" (id, "moduleId", "agentId", content, "fileUrl", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FinalWorkReview; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."FinalWorkReview" (id, "workId", "collaboratorId", feedback, approved, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FinancialEntry; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."FinancialEntry" (id, type, amount, description, "occurredAt", "targetType", "targetId", "targetName", "categoryId", "recordedById", "investmentId", "allocationId", "createdAt", "updatedAt") FROM stdin;
785a05e8-f333-4188-bd57-3cae0e1a8eee	INCOME	100	Doação Anônima	2026-04-17 00:00:00	ORGANIZATION	\N	\N	ff9b1f8d-0ba9-4d38-9f3c-ac8109dd3a90	f4c7f164-34ef-4255-b5be-3083f1d70897	\N	\N	2026-04-17 03:28:06.397	2026-04-17 03:28:06.397
\.


--
-- Data for Name: Investment; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Investment" (id, amount, description, "targetType", "targetId", "targetName", "recordedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Language; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Language" (id, name, code, "createdAt", "updatedAt") FROM stdin;
b2150ccb-9a7c-4931-a1be-7673f0486a4f	Português	pt	2026-04-20 23:49:20.314	2026-04-20 23:49:20.314
0f0c559d-3c97-488f-a2c8-eb75504b12cd	Inglês	en	2026-04-20 23:49:20.325	2026-04-20 23:49:20.325
4967a5d7-f599-4e7c-9b57-f3a65de949ab	Espanhol	es	2026-04-20 23:49:20.328	2026-04-20 23:49:20.328
46eab5c8-d560-429f-a167-6e6a85ca18db	Francês	fr	2026-04-20 23:49:20.33	2026-04-20 23:49:20.33
fc6f1b40-f8f9-47ad-bc7e-3a08b401447b	Alemão	de	2026-04-20 23:49:20.333	2026-04-20 23:49:20.333
8aa12e3e-c40d-4cd7-87ea-eb3b808379e0	Mandarim	zh	2026-04-20 23:49:20.339	2026-04-20 23:49:20.339
33db9646-12b2-4443-947d-fb556ef138d7	Japonês	ja	2026-04-20 23:49:20.342	2026-04-20 23:49:20.342
869f3a5b-f658-46ec-a720-c38db05850df	Coreano	ko	2026-04-20 23:49:20.347	2026-04-20 23:49:20.347
ec17bff5-59e3-4433-8333-60c9e1cc3d29	Hebraico	he	2026-04-20 23:49:20.351	2026-04-20 23:49:20.351
78a09511-1cac-43bf-9af8-70d929d05f65	Árabe	ar	2026-04-20 23:49:20.355	2026-04-20 23:49:20.355
a8836dd2-6a4b-4919-8461-be565e8f0b54	Russo	ru	2026-04-20 23:49:20.359	2026-04-20 23:49:20.359
c7b066b1-0812-446f-819f-0025f74b1ce8	Italiano	it	2026-04-20 23:49:20.363	2026-04-20 23:49:20.363
8ccb1f05-5e8c-4b31-bbb1-602756ac0971	Holandês	nl	2026-04-20 23:49:20.367	2026-04-20 23:49:20.367
ee333998-e1aa-40c1-9342-7d1e1a65abd2	Grego	el	2026-04-20 23:49:20.37	2026-04-20 23:49:20.37
58943c81-0720-48be-b649-d1ac5aa01d3b	Hindi	hi	2026-04-20 23:49:20.373	2026-04-20 23:49:20.373
e593ac6a-169b-48f2-8a2b-9377f6b0c3a0	Bengali	bn	2026-04-20 23:49:20.376	2026-04-20 23:49:20.376
c2280221-bcfa-4b00-b2a8-24740f5d6ad0	Punjabi	pa	2026-04-20 23:49:20.38	2026-04-20 23:49:20.38
854b6a0f-260c-432d-af19-570a7a0255fa	Turco	tr	2026-04-20 23:49:20.384	2026-04-20 23:49:20.384
708d07b7-ae26-4593-ab1d-41b765beb4eb	Tailandês	th	2026-04-20 23:49:20.386	2026-04-20 23:49:20.386
14fbd681-369c-472b-bb71-bfa209022990	Vietnamita	vi	2026-04-20 23:49:20.389	2026-04-20 23:49:20.389
e817f157-48c6-4961-95fa-adab928585de	Suaíli	sw	2026-04-20 23:49:20.392	2026-04-20 23:49:20.392
c4c819c2-f299-45d9-b4a1-1d99cff00ed7	Urdu	ur	2026-04-20 23:49:20.394	2026-04-20 23:49:20.394
1cf0fdac-7823-4e90-9d5f-d4411283597b	Indonésio	id	2026-04-20 23:49:20.397	2026-04-20 23:49:20.397
66dbea45-492d-41cb-ac89-d3675fb918ee	Tâmil	ta	2026-04-20 23:49:20.403	2026-04-20 23:49:20.403
1b5728b4-9d79-4ee5-a61b-9c9a9bbb391e	Telugu	te	2026-04-20 23:49:20.406	2026-04-20 23:49:20.406
77213840-38a2-4618-b992-4569fed59f86	Marati	mr	2026-04-20 23:49:20.409	2026-04-20 23:49:20.409
ba0c7e5d-9999-47bb-be21-d4bb59ce1802	Persa	fa	2026-04-20 23:49:20.412	2026-04-20 23:49:20.412
0cd56bfc-1358-4587-8c30-4c3395e76fdc	Hauçá	ha	2026-04-20 23:49:20.415	2026-04-20 23:49:20.415
1271582c-1eda-41e3-a505-33d82a2a86ff	Canarim	kn	2026-04-20 23:49:20.417	2026-04-20 23:49:20.417
e2c74a6b-d73b-4f1c-977e-a23344622066	Gujarati	gu	2026-04-20 23:49:20.42	2026-04-20 23:49:20.42
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Lesson" (id, "moduleId", title, description, "youtubeUrl", "order", "createdAt", "updatedAt") FROM stdin;
edd433c8-0af8-48a0-88ad-0f2922e109f4	27f02c53-5add-4538-a478-d36a270c4be4	Primeiros passos Aula 01	Primeiros passos como empreendedor do reino	https://youtu.be/ITJN9llt8Ag?si=WCzrTwPNdK9GtycX	1	2026-04-15 16:13:06.569	2026-04-15 16:13:06.569
\.


--
-- Data for Name: LessonAnswer; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."LessonAnswer" (id, "questionId", "collaboratorId", content, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LessonMaterial; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."LessonMaterial" (id, "lessonId", title, url, "createdAt") FROM stdin;
\.


--
-- Data for Name: LessonProgress; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."LessonProgress" (id, "lessonId", "agentId", "completedAt") FROM stdin;
\.


--
-- Data for Name: LessonQuestion; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."LessonQuestion" (id, "lessonId", "agentId", content, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Nationality; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Nationality" (id, name, code, "createdAt", "updatedAt") FROM stdin;
0adff9fc-566a-42b1-b2d1-9116f282e963	Brasileira	BR	2026-04-20 23:49:20.423	2026-04-20 23:49:20.423
595f5365-4944-41ed-9211-086c2e3de70b	Americana	US	2026-04-20 23:49:20.43	2026-04-20 23:49:20.43
6aef4420-42ee-468a-a236-f07d417406c2	Canadense	CA	2026-04-20 23:49:20.434	2026-04-20 23:49:20.434
8c1fb29f-d4d6-4674-8362-34fc41aae099	Mexicana	MX	2026-04-20 23:49:20.438	2026-04-20 23:49:20.438
0b2a62a4-8d7c-436c-a1af-862cf8770423	Portuguesa	PT	2026-04-20 23:49:20.44	2026-04-20 23:49:20.44
a7dcdc11-fa80-4fd8-84b0-f82e531e7aa0	Espanhola	ES	2026-04-20 23:49:20.443	2026-04-20 23:49:20.443
8ed2417a-391a-4f13-bb23-12bb3b6277cd	Francesa	FR	2026-04-20 23:49:20.445	2026-04-20 23:49:20.445
04128105-27a3-4b98-bd19-c6b289a4400e	Italiana	IT	2026-04-20 23:49:20.447	2026-04-20 23:49:20.447
b4a405a2-aee6-4e8f-8c35-07dd9feb80fb	Alemã	DE	2026-04-20 23:49:20.449	2026-04-20 23:49:20.449
a35d2e77-9ea8-44fc-b67c-fcda8b7445ed	Britânica	UK	2026-04-20 23:49:20.452	2026-04-20 23:49:20.452
380833b1-774e-4ff7-94fb-c5df5e760953	Irlandesa	IE	2026-04-20 23:49:20.455	2026-04-20 23:49:20.455
1b7b81b9-5586-4599-b7c9-8fc76a555f3a	Japonesa	JP	2026-04-20 23:49:20.458	2026-04-20 23:49:20.458
b2e946c0-83ef-4643-a38d-2e626d20b5ad	Chinesa	CN	2026-04-20 23:49:20.461	2026-04-20 23:49:20.461
ab77b28d-67af-4529-a218-168bf548a365	Sul-Coreana	KR	2026-04-20 23:49:20.463	2026-04-20 23:49:20.463
1eb07e76-ebd5-46ec-a9df-f6dbad6773da	Indiana	IN	2026-04-20 23:49:20.465	2026-04-20 23:49:20.465
965bf28c-e166-4348-846d-e9cc9acb651b	Australiana	AU	2026-04-20 23:49:20.468	2026-04-20 23:49:20.468
62da7c9a-cbf9-443e-b647-9303620981c9	Neozelandesa	NZ	2026-04-20 23:49:20.471	2026-04-20 23:49:20.471
9afbadb8-ca43-473d-9ed9-607ac21fd88e	Sul-Africana	ZA	2026-04-20 23:49:20.476	2026-04-20 23:49:20.476
da2a4984-61eb-42f9-aea8-f2de5d758b4c	Argentina	AR	2026-04-20 23:49:20.478	2026-04-20 23:49:20.478
50e39d41-eb88-46fc-b91e-39cde400fe9c	Chilena	CL	2026-04-20 23:49:20.48	2026-04-20 23:49:20.48
3a0cd977-416b-475b-81e1-b6883f998753	Peruana	PE	2026-04-20 23:49:20.483	2026-04-20 23:49:20.483
943309fc-8577-44c7-851f-ca80bae299ec	Colombiana	CO	2026-04-20 23:49:20.487	2026-04-20 23:49:20.487
35205f28-8cf1-4568-87a1-faa6d5b8be61	Uruguaia	UY	2026-04-20 23:49:20.489	2026-04-20 23:49:20.489
9729fc84-34f3-4283-9de3-40e311dee01b	Paraguaia	PY	2026-04-20 23:49:20.492	2026-04-20 23:49:20.492
d438fa2a-bcf2-4e84-bff3-da91135ab3fb	Russa	RU	2026-04-20 23:49:20.494	2026-04-20 23:49:20.494
a91a8be5-2736-4c66-bcfa-1810c4f78edf	Turca	TR	2026-04-20 23:49:20.496	2026-04-20 23:49:20.496
c3a92f1e-96c4-435a-9a11-3a11ec0b743b	Holandesa	NL	2026-04-20 23:49:20.498	2026-04-20 23:49:20.498
e78f0b03-b0ad-47d7-ab10-cdbc5e026b41	Suíça	CH	2026-04-20 23:49:20.501	2026-04-20 23:49:20.501
d14aacd9-2f73-4622-be3f-30fdc8261d7d	Sueca	SE	2026-04-20 23:49:20.503	2026-04-20 23:49:20.503
8523930b-665d-43bc-918b-43830245fb4e	Angolana	AO	2026-04-20 23:49:20.506	2026-04-20 23:49:20.506
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Notification" (id, type, scope, title, message, "actionUrl", metadata, "sourceEntityType", "sourceEntityId", "senderAgentId", "senderCollaboratorId", "senderSystemLabel", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NotificationEmailLog; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."NotificationEmailLog" (id, "notificationId", "senderCollaboratorId", "targetType", "agentId", "empreendimentoId", "recipientName", "recipientEmail", subject, message, status, provider, "errorMessage", "createdAt") FROM stdin;
\.


--
-- Data for Name: NotificationRecipient; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."NotificationRecipient" (id, "notificationId", "targetType", "agentId", "collaboratorId", "empreendimentoId", "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Opportunity; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Opportunity" (id, title, description, category, location, "isRemote", "isPublished", "authorCollaboratorId", "authorAgentId", "empreendimentoId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PrayerRequest; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."PrayerRequest" (id, "agentId", request, status, "answeredById", "answeredAt", "internalNote", "createdAt", "updatedAt") FROM stdin;
cdbd2175-121f-4b0a-a945-f96a6ffa09cd	908af585-b754-49a6-81d8-ef7b4fd93450	Pelo meu querido esposo	PENDING	\N	\N	\N	2026-04-21 02:39:54.667	2026-04-21 02:39:54.667
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Question" (id, title, "isRequired", "createdAt", "updatedAt") FROM stdin;
d8ef0317-d808-432b-b3d7-0cb011f740ba	Como nos encontrou?	t	2026-04-21 00:42:19.178	2026-04-21 00:42:19.178
\.


--
-- Data for Name: ServiceLog; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."ServiceLog" (id, "empreendimentoId", "collaboratorId", action, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: ServiceRequest; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."ServiceRequest" (id, "agentId", category, status, description, "assignedCollaboratorId", "internalNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Skill; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."Skill" (id, name, description, "createdAt", "updatedAt") FROM stdin;
00b6036b-9b48-4b0a-91e3-4ff7d328f633	Liderança		2026-04-20 22:30:02.176	2026-04-20 22:30:02.176
345c24d4-aa3b-4648-bdaa-c6e3b891a67c	Ensino		2026-04-20 22:30:06.614	2026-04-20 22:30:06.614
4f401e8b-6fe7-44f8-bd27-8f1d29d6b82c	Tradução		2026-04-20 22:31:59.576	2026-04-20 22:31:59.576
a6cc11de-8db6-4770-a0a2-11b11ca27509	Escrita		2026-04-20 23:31:43.127	2026-04-20 23:31:43.127
2a36cc77-3d42-43c6-96f1-581daa0843c3	Plantação de Igrejas		2026-04-20 23:32:03.532	2026-04-20 23:32:03.532
80cafa87-1919-4e1c-ae5a-109a37fb2bf2	Administração		2026-04-20 23:41:18	2026-04-20 23:41:18
ec2506b4-3376-4a19-8645-a9bab748fff9	Captação de Recursos		2026-04-20 23:41:43.867	2026-04-20 23:41:43.867
\.


--
-- Data for Name: VocationalArea; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app."VocationalArea" (id, name, description, "createdAt", "updatedAt") FROM stdin;
71876e1d-0001-497b-b291-ebcf1704f464	Medicina e Sáude		2026-04-20 23:33:42.339	2026-04-20 23:33:42.339
074efdc6-e16a-401c-8cc9-fde5e7640762	Ensino e Discipulado		2026-04-20 23:34:16.642	2026-04-20 23:34:16.642
9e4e9422-1e0d-419f-adc2-07b1aaf6bfbc	Contexto Musical		2026-04-20 23:36:14.889	2026-04-20 23:36:14.889
e1af338b-2d85-4d74-8a4e-6d2e64df6172	Esportes		2026-04-20 23:36:45.938	2026-04-20 23:36:45.938
d1fa0b9d-1491-4317-b8db-f922e8f586d0	Negócios como Missão		2026-04-20 23:37:04.468	2026-04-20 23:37:04.468
25257503-dc37-414b-952c-3284c512346e	Serviços para PcD		2026-04-20 23:40:27.788	2026-04-20 23:40:27.788
aa606ac7-ff4a-434e-9547-b2dcb70daa8f	Artes Visuais		2026-04-20 23:40:53.291	2026-04-20 23:40:53.291
c40976c3-1e02-4859-9257-4c82ab2691f3	Comunicação e Mídias		2026-04-20 23:42:11.923	2026-04-20 23:42:11.923
46215215-cf48-48ae-a7af-d5032c99cc90	Povos Indígenas		2026-04-20 23:43:00.503	2026-04-20 23:43:00.503
87465986-3cbb-4851-9303-d17e61177221	Povos Quilombolas		2026-04-20 23:43:12.909	2026-04-20 23:43:12.909
1d703331-a604-42ee-a802-b45493d44c4a	Trabalho em Células		2026-04-20 23:44:36.734	2026-04-20 23:44:36.734
03437a04-824f-4520-85d4-cdbcea997ca1	Intercessão		2026-04-20 23:45:19.896	2026-04-20 23:45:19.896
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e62ba5db-f847-422d-95de-cdb231a9508b	6de00eb97df7a9de58a8cf91057e02bae45ed2115752b95bcf1aa741c1ad3261	2026-04-15 15:34:24.253209+00	20260409045649_add_event_rsvp	\N	\N	2026-04-15 15:34:24.049506+00	1
bc12cb6a-73ee-4c72-ae82-eeb987f915c4	a4eed9506952150e23e1163771d990d5d63e1952ff89a4f409956f86f1fafa73	2026-04-15 15:34:24.268899+00	20260410031026_add_prayer_request	\N	\N	2026-04-15 15:34:24.254764+00	1
ae9c9f28-c6c9-4732-acd3-73009b228a74	61cef6b4b95b9e999288cf1fd17bd7f9bd0455cadac71b0b7bd7d76b8053e6e1	2026-04-15 15:34:24.356745+00	20260411144111_academy	\N	\N	2026-04-15 15:34:24.270407+00	1
849d8b03-0016-499a-8b46-401eead5873e	a7e26171b675e036df2c4f3e7ef823316e21656939dae8488715218a3469eb06	2026-04-15 15:34:24.36266+00	20260411180905_add_work_instructions_to_academy_module	\N	\N	2026-04-15 15:34:24.357882+00	1
4b615378-e007-4416-8973-61c316c2df77	7220009f7359557e4b61b141fdb1fec9464e286a8e5e06132a9b4a013e54b727	2026-04-15 15:34:24.412425+00	20260412140000_add_notification_center	\N	\N	2026-04-15 15:34:24.363361+00	1
15af1cff-f458-44db-832f-78437ede2d93	e9a181eb1461091198f02460cc8e8ee8d3f0e285b2298aeac9bbd66754929be3	2026-04-15 15:34:24.448169+00	20260414171502_add_opportunities	\N	\N	2026-04-15 15:34:24.413127+00	1
e888fb87-3340-4c7f-95ad-3e052ea62ad6	6874eea700ac045988492c559b9295fba8040e75b29dda8bdcd34de1a5a498d7	2026-04-15 15:34:24.468207+00	20260414202846_add_agent_investments	\N	\N	2026-04-15 15:34:24.44887+00	1
cde059c5-cd19-4d0d-bb3b-c4cdd56fe22e	6a32586a9cf2203d6d43872706cf79d0e315cd8c36415a31158360797b9c6bac	2026-04-15 15:34:24.479406+00	20260415012847_add_audit_log_fields	\N	\N	2026-04-15 15:34:24.46892+00	1
eb9fe916-4539-45d5-a543-ac10a83cffac	manual_apply_agent_profile_tables	2026-04-20 06:33:57.606378+00	20260420070000_add_agent_profile_tables	\N	\N	2026-04-20 06:33:57.606378+00	1
c2aec470-0b39-4db1-b22f-62be58a45cec	d49d73d7310dc6d9eb2bed415b0dc40f0810c212f8998e1f66b7354cfb58bdaa	2026-04-20 22:15:48.202796+00	20260420140113_merge_profile_update	\N	\N	2026-04-20 21:52:15.3526+00	1
2c0feee4-cead-4d34-aced-26c7ad6564f4	manual-fix-language-proficiency-schema	2026-04-21 00:33:28.527564+00	20260421003000_fix_language_proficiency_schema	\N	\N	2026-04-21 00:33:28.527564+00	1
\.


--
-- Name: AcademyModule AcademyModule_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AcademyModule"
    ADD CONSTRAINT "AcademyModule_pkey" PRIMARY KEY (id);


--
-- Name: AgentCertification AgentCertification_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentCertification"
    ADD CONSTRAINT "AgentCertification_pkey" PRIMARY KEY (id);


--
-- Name: AgentCourse AgentCourse_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentCourse"
    ADD CONSTRAINT "AgentCourse_pkey" PRIMARY KEY (id);


--
-- Name: AgentEducation AgentEducation_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentEducation"
    ADD CONSTRAINT "AgentEducation_pkey" PRIMARY KEY (id);


--
-- Name: AgentExperience AgentExperience_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentExperience"
    ADD CONSTRAINT "AgentExperience_pkey" PRIMARY KEY (id);


--
-- Name: AgentInvestment AgentInvestment_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentInvestment"
    ADD CONSTRAINT "AgentInvestment_pkey" PRIMARY KEY (id);


--
-- Name: AgentLanguage AgentLanguage_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentLanguage"
    ADD CONSTRAINT "AgentLanguage_pkey" PRIMARY KEY ("agentId", "languageId");


--
-- Name: AgentLink AgentLink_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentLink"
    ADD CONSTRAINT "AgentLink_pkey" PRIMARY KEY (id);


--
-- Name: AgentModuleEnrollment AgentModuleEnrollment_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentModuleEnrollment"
    ADD CONSTRAINT "AgentModuleEnrollment_pkey" PRIMARY KEY ("agentId", "moduleId");


--
-- Name: AgentRecommendation AgentRecommendation_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentRecommendation"
    ADD CONSTRAINT "AgentRecommendation_pkey" PRIMARY KEY (id);


--
-- Name: AgentSkill AgentSkill_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentSkill"
    ADD CONSTRAINT "AgentSkill_pkey" PRIMARY KEY ("agentId", "skillId");


--
-- Name: AgentVocationalArea AgentVocationalArea_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentVocationalArea"
    ADD CONSTRAINT "AgentVocationalArea_pkey" PRIMARY KEY ("agentId", "vocationalAreaId");


--
-- Name: Agent Agent_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Agent"
    ADD CONSTRAINT "Agent_pkey" PRIMARY KEY (id);


--
-- Name: Allocation Allocation_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Allocation"
    ADD CONSTRAINT "Allocation_pkey" PRIMARY KEY (id);


--
-- Name: Announcement Announcement_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Announcement"
    ADD CONSTRAINT "Announcement_pkey" PRIMARY KEY (id);


--
-- Name: Answer Answer_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Answer"
    ADD CONSTRAINT "Answer_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: AvailabilitySlot AvailabilitySlot_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AvailabilitySlot"
    ADD CONSTRAINT "AvailabilitySlot_pkey" PRIMARY KEY (id);


--
-- Name: Collaborator Collaborator_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Collaborator"
    ADD CONSTRAINT "Collaborator_pkey" PRIMARY KEY (id);


--
-- Name: Connection Connection_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Connection"
    ADD CONSTRAINT "Connection_pkey" PRIMARY KEY (id);


--
-- Name: EmpreendimentoFollow EmpreendimentoFollow_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoFollow"
    ADD CONSTRAINT "EmpreendimentoFollow_pkey" PRIMARY KEY ("agentId", "empreendimentoId");


--
-- Name: EmpreendimentoInvite EmpreendimentoInvite_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoInvite"
    ADD CONSTRAINT "EmpreendimentoInvite_pkey" PRIMARY KEY (id);


--
-- Name: EmpreendimentoMember EmpreendimentoMember_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoMember"
    ADD CONSTRAINT "EmpreendimentoMember_pkey" PRIMARY KEY ("agentId", "empreendimentoId");


--
-- Name: Empreendimento Empreendimento_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Empreendimento"
    ADD CONSTRAINT "Empreendimento_pkey" PRIMARY KEY (id);


--
-- Name: EventRsvp EventRsvp_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EventRsvp"
    ADD CONSTRAINT "EventRsvp_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseCategory ExpenseCategory_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ExpenseCategory"
    ADD CONSTRAINT "ExpenseCategory_pkey" PRIMARY KEY (id);


--
-- Name: ExperienceType ExperienceType_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ExperienceType"
    ADD CONSTRAINT "ExperienceType_pkey" PRIMARY KEY (id);


--
-- Name: FinalWorkReview FinalWorkReview_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWorkReview"
    ADD CONSTRAINT "FinalWorkReview_pkey" PRIMARY KEY (id);


--
-- Name: FinalWork FinalWork_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWork"
    ADD CONSTRAINT "FinalWork_pkey" PRIMARY KEY (id);


--
-- Name: FinancialEntry FinancialEntry_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinancialEntry"
    ADD CONSTRAINT "FinancialEntry_pkey" PRIMARY KEY (id);


--
-- Name: Investment Investment_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Investment"
    ADD CONSTRAINT "Investment_pkey" PRIMARY KEY (id);


--
-- Name: Language Language_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Language"
    ADD CONSTRAINT "Language_pkey" PRIMARY KEY (id);


--
-- Name: LessonAnswer LessonAnswer_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonAnswer"
    ADD CONSTRAINT "LessonAnswer_pkey" PRIMARY KEY (id);


--
-- Name: LessonMaterial LessonMaterial_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonMaterial"
    ADD CONSTRAINT "LessonMaterial_pkey" PRIMARY KEY (id);


--
-- Name: LessonProgress LessonProgress_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonProgress"
    ADD CONSTRAINT "LessonProgress_pkey" PRIMARY KEY (id);


--
-- Name: LessonQuestion LessonQuestion_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonQuestion"
    ADD CONSTRAINT "LessonQuestion_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: Nationality Nationality_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Nationality"
    ADD CONSTRAINT "Nationality_pkey" PRIMARY KEY (id);


--
-- Name: NotificationEmailLog NotificationEmailLog_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationEmailLog"
    ADD CONSTRAINT "NotificationEmailLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationRecipient NotificationRecipient_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationRecipient"
    ADD CONSTRAINT "NotificationRecipient_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Opportunity Opportunity_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Opportunity"
    ADD CONSTRAINT "Opportunity_pkey" PRIMARY KEY (id);


--
-- Name: PrayerRequest PrayerRequest_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."PrayerRequest"
    ADD CONSTRAINT "PrayerRequest_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: ServiceLog ServiceLog_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceLog"
    ADD CONSTRAINT "ServiceLog_pkey" PRIMARY KEY (id);


--
-- Name: ServiceRequest ServiceRequest_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_pkey" PRIMARY KEY (id);


--
-- Name: Skill Skill_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Skill"
    ADD CONSTRAINT "Skill_pkey" PRIMARY KEY (id);


--
-- Name: VocationalArea VocationalArea_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."VocationalArea"
    ADD CONSTRAINT "VocationalArea_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AgentCertification_agentId_moduleId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "AgentCertification_agentId_moduleId_key" ON app."AgentCertification" USING btree ("agentId", "moduleId");


--
-- Name: AgentInvestment_investorId_investedAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AgentInvestment_investorId_investedAt_idx" ON app."AgentInvestment" USING btree ("investorId", "investedAt");


--
-- Name: AgentInvestment_targetAgentId_investedAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AgentInvestment_targetAgentId_investedAt_idx" ON app."AgentInvestment" USING btree ("targetAgentId", "investedAt");


--
-- Name: AgentInvestment_targetEmpreendimentoId_investedAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AgentInvestment_targetEmpreendimentoId_investedAt_idx" ON app."AgentInvestment" USING btree ("targetEmpreendimentoId", "investedAt");


--
-- Name: Agent_authSubject_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Agent_authSubject_key" ON app."Agent" USING btree ("authSubject");


--
-- Name: Agent_email_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Agent_email_key" ON app."Agent" USING btree (email);


--
-- Name: Agent_scheduledSlotId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Agent_scheduledSlotId_key" ON app."Agent" USING btree ("scheduledSlotId");


--
-- Name: Agent_slug_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Agent_slug_key" ON app."Agent" USING btree (slug);


--
-- Name: Answer_agentId_questionId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Answer_agentId_questionId_key" ON app."Answer" USING btree ("agentId", "questionId");


--
-- Name: AuditLog_actionType_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AuditLog_actionType_idx" ON app."AuditLog" USING btree ("actionType");


--
-- Name: AuditLog_actorId_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AuditLog_actorId_idx" ON app."AuditLog" USING btree ("actorId");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AuditLog_createdAt_idx" ON app."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_entity_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "AuditLog_entity_idx" ON app."AuditLog" USING btree (entity);


--
-- Name: Collaborator_authSubject_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Collaborator_authSubject_key" ON app."Collaborator" USING btree ("authSubject");


--
-- Name: Collaborator_email_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Collaborator_email_key" ON app."Collaborator" USING btree (email);


--
-- Name: Connection_senderId_receiverId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Connection_senderId_receiverId_key" ON app."Connection" USING btree ("senderId", "receiverId");


--
-- Name: EmpreendimentoInvite_token_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "EmpreendimentoInvite_token_key" ON app."EmpreendimentoInvite" USING btree (token);


--
-- Name: EventRsvp_eventId_agentId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "EventRsvp_eventId_agentId_key" ON app."EventRsvp" USING btree ("eventId", "agentId");


--
-- Name: ExpenseCategory_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "ExpenseCategory_name_key" ON app."ExpenseCategory" USING btree (name);


--
-- Name: ExperienceType_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "ExperienceType_name_key" ON app."ExperienceType" USING btree (name);


--
-- Name: FinalWorkReview_workId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "FinalWorkReview_workId_key" ON app."FinalWorkReview" USING btree ("workId");


--
-- Name: FinalWork_moduleId_agentId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "FinalWork_moduleId_agentId_key" ON app."FinalWork" USING btree ("moduleId", "agentId");


--
-- Name: FinancialEntry_allocationId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "FinancialEntry_allocationId_key" ON app."FinancialEntry" USING btree ("allocationId");


--
-- Name: FinancialEntry_investmentId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "FinancialEntry_investmentId_key" ON app."FinancialEntry" USING btree ("investmentId");


--
-- Name: Language_code_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Language_code_key" ON app."Language" USING btree (code);


--
-- Name: Language_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Language_name_key" ON app."Language" USING btree (name);


--
-- Name: LessonProgress_lessonId_agentId_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "LessonProgress_lessonId_agentId_key" ON app."LessonProgress" USING btree ("lessonId", "agentId");


--
-- Name: Nationality_code_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Nationality_code_key" ON app."Nationality" USING btree (code);


--
-- Name: Nationality_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Nationality_name_key" ON app."Nationality" USING btree (name);


--
-- Name: NotificationEmailLog_empreendimentoId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationEmailLog_empreendimentoId_createdAt_idx" ON app."NotificationEmailLog" USING btree ("empreendimentoId", "createdAt");


--
-- Name: NotificationEmailLog_recipientEmail_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationEmailLog_recipientEmail_createdAt_idx" ON app."NotificationEmailLog" USING btree ("recipientEmail", "createdAt");


--
-- Name: NotificationEmailLog_senderCollaboratorId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationEmailLog_senderCollaboratorId_createdAt_idx" ON app."NotificationEmailLog" USING btree ("senderCollaboratorId", "createdAt");


--
-- Name: NotificationRecipient_agentId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationRecipient_agentId_createdAt_idx" ON app."NotificationRecipient" USING btree ("agentId", "createdAt");


--
-- Name: NotificationRecipient_collaboratorId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationRecipient_collaboratorId_createdAt_idx" ON app."NotificationRecipient" USING btree ("collaboratorId", "createdAt");


--
-- Name: NotificationRecipient_empreendimentoId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationRecipient_empreendimentoId_createdAt_idx" ON app."NotificationRecipient" USING btree ("empreendimentoId", "createdAt");


--
-- Name: NotificationRecipient_notificationId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "NotificationRecipient_notificationId_createdAt_idx" ON app."NotificationRecipient" USING btree ("notificationId", "createdAt");


--
-- Name: Notification_senderCollaboratorId_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "Notification_senderCollaboratorId_createdAt_idx" ON app."Notification" USING btree ("senderCollaboratorId", "createdAt");


--
-- Name: Notification_type_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "Notification_type_createdAt_idx" ON app."Notification" USING btree (type, "createdAt");


--
-- Name: Opportunity_category_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "Opportunity_category_createdAt_idx" ON app."Opportunity" USING btree (category, "createdAt");


--
-- Name: Opportunity_isPublished_createdAt_idx; Type: INDEX; Schema: app; Owner: -
--

CREATE INDEX "Opportunity_isPublished_createdAt_idx" ON app."Opportunity" USING btree ("isPublished", "createdAt");


--
-- Name: Skill_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "Skill_name_key" ON app."Skill" USING btree (name);


--
-- Name: VocationalArea_name_key; Type: INDEX; Schema: app; Owner: -
--

CREATE UNIQUE INDEX "VocationalArea_name_key" ON app."VocationalArea" USING btree (name);


--
-- Name: AgentCertification AgentCertification_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentCertification"
    ADD CONSTRAINT "AgentCertification_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentCertification AgentCertification_moduleId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentCertification"
    ADD CONSTRAINT "AgentCertification_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES app."AcademyModule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentCourse AgentCourse_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentCourse"
    ADD CONSTRAINT "AgentCourse_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentEducation AgentEducation_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentEducation"
    ADD CONSTRAINT "AgentEducation_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentExperience AgentExperience_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentExperience"
    ADD CONSTRAINT "AgentExperience_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentExperience AgentExperience_experienceTypeId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentExperience"
    ADD CONSTRAINT "AgentExperience_experienceTypeId_fkey" FOREIGN KEY ("experienceTypeId") REFERENCES app."ExperienceType"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AgentInvestment AgentInvestment_investorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentInvestment"
    ADD CONSTRAINT "AgentInvestment_investorId_fkey" FOREIGN KEY ("investorId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentInvestment AgentInvestment_targetAgentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentInvestment"
    ADD CONSTRAINT "AgentInvestment_targetAgentId_fkey" FOREIGN KEY ("targetAgentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AgentInvestment AgentInvestment_targetEmpreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentInvestment"
    ADD CONSTRAINT "AgentInvestment_targetEmpreendimentoId_fkey" FOREIGN KEY ("targetEmpreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AgentLanguage AgentLanguage_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentLanguage"
    ADD CONSTRAINT "AgentLanguage_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentLanguage AgentLanguage_languageId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentLanguage"
    ADD CONSTRAINT "AgentLanguage_languageId_fkey" FOREIGN KEY ("languageId") REFERENCES app."Language"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentLink AgentLink_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentLink"
    ADD CONSTRAINT "AgentLink_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentModuleEnrollment AgentModuleEnrollment_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentModuleEnrollment"
    ADD CONSTRAINT "AgentModuleEnrollment_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentModuleEnrollment AgentModuleEnrollment_moduleId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentModuleEnrollment"
    ADD CONSTRAINT "AgentModuleEnrollment_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES app."AcademyModule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentRecommendation AgentRecommendation_recommendedId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentRecommendation"
    ADD CONSTRAINT "AgentRecommendation_recommendedId_fkey" FOREIGN KEY ("recommendedId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentRecommendation AgentRecommendation_recommenderId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentRecommendation"
    ADD CONSTRAINT "AgentRecommendation_recommenderId_fkey" FOREIGN KEY ("recommenderId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentSkill AgentSkill_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentSkill"
    ADD CONSTRAINT "AgentSkill_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentSkill AgentSkill_skillId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentSkill"
    ADD CONSTRAINT "AgentSkill_skillId_fkey" FOREIGN KEY ("skillId") REFERENCES app."Skill"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentVocationalArea AgentVocationalArea_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentVocationalArea"
    ADD CONSTRAINT "AgentVocationalArea_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentVocationalArea AgentVocationalArea_vocationalAreaId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AgentVocationalArea"
    ADD CONSTRAINT "AgentVocationalArea_vocationalAreaId_fkey" FOREIGN KEY ("vocationalAreaId") REFERENCES app."VocationalArea"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Agent Agent_nationalityId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Agent"
    ADD CONSTRAINT "Agent_nationalityId_fkey" FOREIGN KEY ("nationalityId") REFERENCES app."Nationality"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Agent Agent_scheduledSlotId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Agent"
    ADD CONSTRAINT "Agent_scheduledSlotId_fkey" FOREIGN KEY ("scheduledSlotId") REFERENCES app."AvailabilitySlot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Allocation Allocation_recordedById_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Allocation"
    ADD CONSTRAINT "Allocation_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Announcement Announcement_authorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Announcement"
    ADD CONSTRAINT "Announcement_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Answer Answer_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Answer"
    ADD CONSTRAINT "Answer_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Answer Answer_questionId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Answer"
    ADD CONSTRAINT "Answer_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES app."Question"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AvailabilitySlot AvailabilitySlot_collaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."AvailabilitySlot"
    ADD CONSTRAINT "AvailabilitySlot_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Connection Connection_receiverId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Connection"
    ADD CONSTRAINT "Connection_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Connection Connection_senderId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Connection"
    ADD CONSTRAINT "Connection_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoFollow EmpreendimentoFollow_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoFollow"
    ADD CONSTRAINT "EmpreendimentoFollow_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoFollow EmpreendimentoFollow_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoFollow"
    ADD CONSTRAINT "EmpreendimentoFollow_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoInvite EmpreendimentoInvite_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoInvite"
    ADD CONSTRAINT "EmpreendimentoInvite_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoInvite EmpreendimentoInvite_inviterId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoInvite"
    ADD CONSTRAINT "EmpreendimentoInvite_inviterId_fkey" FOREIGN KEY ("inviterId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoMember EmpreendimentoMember_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoMember"
    ADD CONSTRAINT "EmpreendimentoMember_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmpreendimentoMember EmpreendimentoMember_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EmpreendimentoMember"
    ADD CONSTRAINT "EmpreendimentoMember_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Empreendimento Empreendimento_internalResponsibleId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Empreendimento"
    ADD CONSTRAINT "Empreendimento_internalResponsibleId_fkey" FOREIGN KEY ("internalResponsibleId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Empreendimento Empreendimento_ownerId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Empreendimento"
    ADD CONSTRAINT "Empreendimento_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EventRsvp EventRsvp_eventId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."EventRsvp"
    ADD CONSTRAINT "EventRsvp_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES app."Event"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FinalWorkReview FinalWorkReview_collaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWorkReview"
    ADD CONSTRAINT "FinalWorkReview_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FinalWorkReview FinalWorkReview_workId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWorkReview"
    ADD CONSTRAINT "FinalWorkReview_workId_fkey" FOREIGN KEY ("workId") REFERENCES app."FinalWork"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FinalWork FinalWork_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWork"
    ADD CONSTRAINT "FinalWork_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FinalWork FinalWork_moduleId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinalWork"
    ADD CONSTRAINT "FinalWork_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES app."AcademyModule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FinancialEntry FinancialEntry_allocationId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinancialEntry"
    ADD CONSTRAINT "FinancialEntry_allocationId_fkey" FOREIGN KEY ("allocationId") REFERENCES app."Allocation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FinancialEntry FinancialEntry_categoryId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinancialEntry"
    ADD CONSTRAINT "FinancialEntry_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES app."ExpenseCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FinancialEntry FinancialEntry_investmentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinancialEntry"
    ADD CONSTRAINT "FinancialEntry_investmentId_fkey" FOREIGN KEY ("investmentId") REFERENCES app."Investment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FinancialEntry FinancialEntry_recordedById_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."FinancialEntry"
    ADD CONSTRAINT "FinancialEntry_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Investment Investment_recordedById_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Investment"
    ADD CONSTRAINT "Investment_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonAnswer LessonAnswer_collaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonAnswer"
    ADD CONSTRAINT "LessonAnswer_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonAnswer LessonAnswer_questionId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonAnswer"
    ADD CONSTRAINT "LessonAnswer_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES app."LessonQuestion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonMaterial LessonMaterial_lessonId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonMaterial"
    ADD CONSTRAINT "LessonMaterial_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES app."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonProgress LessonProgress_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonProgress"
    ADD CONSTRAINT "LessonProgress_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonProgress LessonProgress_lessonId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonProgress"
    ADD CONSTRAINT "LessonProgress_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES app."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonQuestion LessonQuestion_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonQuestion"
    ADD CONSTRAINT "LessonQuestion_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonQuestion LessonQuestion_lessonId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."LessonQuestion"
    ADD CONSTRAINT "LessonQuestion_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES app."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lesson Lesson_moduleId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Lesson"
    ADD CONSTRAINT "Lesson_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES app."AcademyModule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationEmailLog NotificationEmailLog_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationEmailLog"
    ADD CONSTRAINT "NotificationEmailLog_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NotificationEmailLog NotificationEmailLog_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationEmailLog"
    ADD CONSTRAINT "NotificationEmailLog_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NotificationEmailLog NotificationEmailLog_notificationId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationEmailLog"
    ADD CONSTRAINT "NotificationEmailLog_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES app."Notification"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NotificationEmailLog NotificationEmailLog_senderCollaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationEmailLog"
    ADD CONSTRAINT "NotificationEmailLog_senderCollaboratorId_fkey" FOREIGN KEY ("senderCollaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationRecipient NotificationRecipient_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationRecipient"
    ADD CONSTRAINT "NotificationRecipient_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationRecipient NotificationRecipient_collaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationRecipient"
    ADD CONSTRAINT "NotificationRecipient_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationRecipient NotificationRecipient_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationRecipient"
    ADD CONSTRAINT "NotificationRecipient_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationRecipient NotificationRecipient_notificationId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."NotificationRecipient"
    ADD CONSTRAINT "NotificationRecipient_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES app."Notification"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_senderAgentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Notification"
    ADD CONSTRAINT "Notification_senderAgentId_fkey" FOREIGN KEY ("senderAgentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_senderCollaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Notification"
    ADD CONSTRAINT "Notification_senderCollaboratorId_fkey" FOREIGN KEY ("senderCollaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Opportunity Opportunity_authorAgentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Opportunity"
    ADD CONSTRAINT "Opportunity_authorAgentId_fkey" FOREIGN KEY ("authorAgentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Opportunity Opportunity_authorCollaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Opportunity"
    ADD CONSTRAINT "Opportunity_authorCollaboratorId_fkey" FOREIGN KEY ("authorCollaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Opportunity Opportunity_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."Opportunity"
    ADD CONSTRAINT "Opportunity_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PrayerRequest PrayerRequest_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."PrayerRequest"
    ADD CONSTRAINT "PrayerRequest_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PrayerRequest PrayerRequest_answeredById_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."PrayerRequest"
    ADD CONSTRAINT "PrayerRequest_answeredById_fkey" FOREIGN KEY ("answeredById") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceLog ServiceLog_collaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceLog"
    ADD CONSTRAINT "ServiceLog_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceLog ServiceLog_empreendimentoId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceLog"
    ADD CONSTRAINT "ServiceLog_empreendimentoId_fkey" FOREIGN KEY ("empreendimentoId") REFERENCES app."Empreendimento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceRequest ServiceRequest_agentId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES app."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceRequest ServiceRequest_assignedCollaboratorId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: -
--

ALTER TABLE ONLY app."ServiceRequest"
    ADD CONSTRAINT "ServiceRequest_assignedCollaboratorId_fkey" FOREIGN KEY ("assignedCollaboratorId") REFERENCES app."Collaborator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ZcPJdcn2h74ebgUTjJytTlNbKSiRCKway7Tfgn6mVd4sisk2c6p5aaiG1lCng2Q

